<?php
header("Content-Type: application/json");
require_once 'db.php'; // Conexión a la base de datos

// Get the raw POST data
$data = json_decode(file_get_contents("php://input"), true);

// Get user ID from POST data
$user_id = isset($data['id']) ? intval($data['id']) : 0;

if ($user_id > 0) {
    $sql = "SELECT nombre, tipus FROM usuari WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        echo json_encode([
            'nombre' => $user['nombre'],
            'tipus' => $user['tipus']
        ]);
    } else {
        echo json_encode(['error' => 'User not found']);
    }

    $stmt = null;
} else {
    echo json_encode(['error' => 'Invalid user ID']);
}

$pdo = null;
?>