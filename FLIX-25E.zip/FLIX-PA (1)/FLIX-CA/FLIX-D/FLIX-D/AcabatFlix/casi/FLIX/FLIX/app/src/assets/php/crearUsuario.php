<?php
require_once 'db.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (
    isset($data['nombre']) &&
    isset($data['email']) &&
    isset($data['rol']) &&
    isset($data['password']) &&
    isset($data['escuela_id'])
) {
    $id = $data['id'];
    $nombre = $data['nombre'];
    $email = $data['email'];
    $rol = $data['rol'];
    $password = $data['password']; // Encriptar la contraseña
    $escuela_id = $data['escuela_id'];

    try {
        $sql = "INSERT INTO usuari (id, nom, email, tipus, contrasenya, id_escola) 
                VALUES (:id, :nombre, :email, :rol, :password, :escuela_id)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':rol', $rol);
        $stmt->bindParam(':password', $password);
        $stmt->bindParam(':escuela_id', $escuela_id);

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Usuario creado correctamente']);
        } else {
            echo json_encode(['success' => false, 'message' => 'No se pudo crear el usuario']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error de conexión: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
}
?>
