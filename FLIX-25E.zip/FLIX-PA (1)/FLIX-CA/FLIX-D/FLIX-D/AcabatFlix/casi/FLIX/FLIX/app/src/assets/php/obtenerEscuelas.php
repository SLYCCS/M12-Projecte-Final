<?php

header("Content-Type: application/json");
require_once 'db.php'; // Conexión a la base de datos

// Verifica si la conexión fue exitosa
if (!$pdo) {
    echo json_encode(['error' => 'Error al conectar con la base de datos.']);
    exit();
}


    try {
        // Obtener profesores y sus datos
        $query = $pdo->prepare("SELECT * FROM escola");
       
        $query->execute();
        $response = $query->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($response);
    } catch (PDOException $e) {
        echo json_encode(['error' => 'Error en la consulta a la base de datos: ' . $e->getMessage()]);
    }
?>
