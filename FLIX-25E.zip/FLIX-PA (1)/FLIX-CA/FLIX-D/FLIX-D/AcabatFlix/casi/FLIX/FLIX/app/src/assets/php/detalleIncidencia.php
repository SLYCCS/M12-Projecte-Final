<?php
require_once 'db.php';

header('Content-Type: application/json');

try {
    // Validar el ID recibido
    if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
        throw new Exception('ID de incidencia no válido');
    }

    $incidenciaId = (int)$_GET['id'];

    // Conexión a la base de datos
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Consulta para obtener los detalles de la incidencia
    $sql = "SELECT 
                i.id,
                i.titol AS titulo,
                i.descripcio AS descripcion,
                i.prioritat AS prioridad,
                i.estat AS estado,
                i.data_incidencia AS fecha_creacion,
                i.id_aula AS id_aula,
                i.id_usuari AS id_usuario,
                u.nom AS nombre_usuario,
                a.nom AS nombre_aula,
                e.id AS escuela_id,
                e.nom AS nombre_escuela
            FROM 
                incidencia i
            LEFT JOIN 
                usuari u ON i.id = u.id
            LEFT JOIN 
                aula a ON i.id = a.id
            LEFT JOIN 
                escola e ON a.id = e.id
            WHERE 
                i.id = ?";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$incidenciaId]);
    $incidencia = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verificar si se encontró la incidencia
    if (!$incidencia) {
        throw new Exception('Incidencia no encontrada');
    }

    // Formatear fechas para consistencia
    $incidencia['fecha_creacion'] = date('Y-m-d H:i:s', strtotime($incidencia['fecha_creacion']));

    // Devolver los datos en formato JSON
    echo json_encode($incidencia);
} catch (Exception $e) {
    // Manejo de errores
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}   
