<?php
require_once 'db.php';


$data = json_decode(file_get_contents('php://input'), true);

$nombre = $data['nom'];
$direccion = $data['direccio'];
try {
    $sql = "INSERT INTO escola (nom, direccio, data_creacio) 
            VALUES (:nombre, :direccion, NOW())";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':nombre', $nombre);
    $stmt->bindParam(':direccion', $direccion);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Escuela creada exitosamente']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al crear la escuela']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Error de conexión: ' . $e->getMessage()]);
}