class IncidenciasManager {
    constructor() {
        this.escuelas = [];
        this.aulas = [];
        this.usuarios = [];
        this.incidenciaActual = null;
        this.init();
    }

    async init() {
        this.verifyAuth();
        await this.cargarTodosLosDatos();
        this.setupEventListeners();
    }

    verifyAuth() {
        const textoCifradoRecuperado = localStorage.getItem('datosCifrados');
        if (!textoCifradoRecuperado) {
            window.location.href = "../login.html";
            return;
        }

        try {
            const dataDescifrada = JSON.parse(this.descifrarCesar(textoCifradoRecuperado, 3));
            document.getElementById('nombreUsuarioBienvenida').innerText = dataDescifrada.nombre;
            
            if (dataDescifrada.rol !== "Admin App") {
                window.location.href = dataDescifrada.rol === "Professor" 
                    ? "../profesor/profesorInicio.html" 
                    : "../adminEscuela/adminEscuelaInicio.html";
            }
        } catch (error) {
            console.error("Error al verificar autenticación:", error);
            window.location.href = "../login.html";
        }
    }

    cifrarCesar(texto, clave) {
        return texto.split('').map(char => {
            if (char.match(/[a-z]/i)) {
                const code = char.charCodeAt(0);
                const base = (char.toLowerCase() === char) ? 97 : 65;
                return String.fromCharCode(((code - base + clave) % 26) + base);
            }
            return char;
        }).join('');
    }

    descifrarCesar(texto, clave) {
        return texto.split('').map(char => {
            if (char.match(/[a-z]/i)) {
                const code = char.charCodeAt(0);
                const base = (char.toLowerCase() === char) ? 97 : 65;
                return String.fromCharCode(((code - base - clave + 26) % 26) + base);
            }
            return char;
        }).join('');
    }

    formatFecha(fechaString) {
        if (!fechaString) return 'No disponible';
        const fecha = new Date(fechaString);
        return isNaN(fecha.getTime()) ? 'Fecha inválida' : fecha.toLocaleDateString('es-ES', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    getPrioridadClass(prioridad) {
        const classes = {
            'Baixa': 'bg-info',
            'Mitja': 'bg-primary',
            'Alta': 'bg-warning'
        };
        return classes[prioridad] || 'bg-secondary';
    }

    async fetchData(url) {
        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error(`Error al cargar datos desde ${url}`);
            return await response.json();
        } catch (error) {
            console.error(error);
            return [];
        }
    }

    async cargarEscuelas() {
        const data = await this.fetchData('../../assets/php/escuelasAdmin.php');
        const selectEscuela = document.getElementById('filtroEscuela');
        
        selectEscuela.innerHTML = '<option value="">Todas</option>';
        data.forEach(escuela => {
            
            const option = document.createElement('option');
            option.value = escuela.id;
            option.textContent = escuela.nom;
            selectEscuela.appendChild(option);
        });
        
        return data;
    }

    async cargarAulas() {
        return this.fetchData('../../assets/php/aulasAdmin.php');
    }

    async cargarUsuarios() {
        return this.fetchData('../../assets/php/usuariosCAdmin.php');
    }

    async cargarTodosLosDatos() {
        try {
            [this.escuelas, this.aulas, this.usuarios] = await Promise.all([
                this.cargarEscuelas(),
                this.cargarAulas(),
                this.cargarUsuarios()
            ]);
            this.mostrarIncidencias();
        } catch (error) {
            console.error('Error al cargar datos:', error);
            this.mostrarIncidencias();
        }
    }

    obtenerNombreUsuario(userId) {
        if (!userId) return 'Desconocido';
        const usuario = this.usuarios.find(u => u.id == userId);
        return usuario ? usuario.nom : 'Desconocido';
    }

    obtenerNombreAula(aulaId) {
        if (!aulaId) return 'Aula desconocida';
        const aula = this.aulas.find(a => a.id == aulaId);
        return aula ? aula.nom : 'Aula desconocida';
    }

    obtenerNombreEscuela(escola_Id) {
        if (!escola_Id) return 'Escuela desconocida';
        const escuela = this.escuelas.find(e => e.id == escola_Id);
        return escuela ? escuela.nom : 'Escuela desconocida';
    }

    obtenerEscuelaDeAula(id_aula) {
        if (!id_aula) return 'Escuela desconocida';
        const aula = this.aulas.find(a => a.id == id_aula);
        return aula ? this.obtenerNombreEscuela(aula.id_escola) : 'Escuela desconocida';
    }
    
    transformarIncidencia(incidencia) {
        
        return {
            ...incidencia,
            aula_nombre: this.obtenerNombreAula(incidencia.id_aula),
            escuela_nombre: this.obtenerEscuelaDeAula(incidencia.id_aula),
            usuario_nombre: this.obtenerNombreUsuario(incidencia.id_usuari),
            fecha_creacion: this.formatFecha(incidencia.data_incidencia),
            prioridadClass: this.getPrioridadClass(incidencia.prioritat)
        };
    }

    async cargarDatosIncidencias() {
        try {
            const data = await this.fetchData('../../assets/php/incidenciasAdmin.php');
            const transformedData = data.map(incidencia => this.transformarIncidencia(incidencia));
            
            return transformedData;
        } catch (error) {
            console.error(error);
            return [];
        }
    }

    renderizarIncidencias(incidencias) {
        const listaIncidencias = document.getElementById('listaIncidencias');
        const contadorIncidencias = document.getElementById('contadorIncidencias');
        listaIncidencias.innerHTML = '';

        if (!Array.isArray(incidencias)) {
            listaIncidencias.innerHTML = this.createErrorRow('Error: Formato de datos incorrecto');
            contadorIncidencias.textContent = '0 incidencias';
            return;
        }

        if (incidencias.length === 0) {
            listaIncidencias.innerHTML = this.createEmptyState();
            contadorIncidencias.textContent = '0 incidencias';
            return;
        }

        incidencias.forEach(incidencia => {
            listaIncidencias.appendChild(this.createIncidenciaRow(incidencia));
        });

        contadorIncidencias.textContent = `${incidencias.length} incidencias`;
    }

    createErrorRow(message) {
        return `
            <tr>
                <td colspan="9" class="text-center py-4 text-danger">
                    ${message}
                </td>
            </tr>
        `;
    }

    createEmptyState() {
        return `
            <tr>
                <td colspan="9" class="text-center py-4">
                    <p class="text-muted">No se encontraron incidencias.</p>
                    <button class="btn btn-primary" onclick="incidenciasManager.limpiarFiltro()">Mostrar todas</button>
                </td>
            </tr>
        `;
    }

    createIncidenciaRow(incidencia) {
        
        const tr = document.createElement('tr');
        tr.style.cursor = 'pointer';
        tr.addEventListener('click', () => this.mostrarDetalleIncidencia(incidencia.id));
        
        tr.innerHTML = `
            <td>${incidencia.id}</td>
            <td>${incidencia.titulo || incidencia.titol}</td>
            <td>${incidencia.escuela_nombre}</td>
            <td>${incidencia.aula_nombre}</td>
            <td>${incidencia.usuario_nombre}</td>
            <td>${incidencia.fecha_creacion}</td>
            <td>
                <span class="badge ${incidencia.prioridadClass}">
                    ${incidencia.prioritat}
                </span>
            </td>
            <td>
                <span class="badge ${incidencia.estat === 'Resuelta' ? 'bg-success' : incidencia.estat === 'Cerrada' ? 'bg-secondary' : 'bg-warning'}">
                    ${incidencia.estat}
                </span>
            </td>
            <td>
                <button class="btn btn-sm btn-outline-primary" onclick="event.stopPropagation(); incidenciasManager.mostrarDetalleIncidencia(${incidencia.id}, event)">
                    <i class="bi bi-eye"></i> Ver
                </button>
            </td>
        `;
        return tr;
    }

    async mostrarIncidencias(incidenciasFiltradas = null) {
        const incidencias = incidenciasFiltradas === null ? await this.cargarDatosIncidencias() : incidenciasFiltradas;
        console.log('incidencias', incidencias);
        
        this.renderizarIncidencias(incidencias);
    }

    async mostrarDetalleIncidencia(id, event = null) {
        if (event) event.stopPropagation();
        
        try {
            const incidencia = await this.fetchData(`../../assets/php/detalleIncidencia.php?id=${id}`);
            
            if (!incidencia.id) throw new Error('Incidencia no encontrada');
            
            this.incidenciaActual = incidencia;
            this.updateModalUI(incidencia);
            
            const modalElement = document.getElementById('modalDetalleIncidencia');
            const modal = bootstrap.Modal.getInstance(modalElement) || new bootstrap.Modal(modalElement);
            
            this.setupModalAccessibility(modalElement);
            modal.show();
            
        } catch (error) {
            console.error('Error al cargar detalles:', error);
            alert('Error al cargar los detalles: ' + error.message);
        }
    }

    updateModalUI(incidencia) {
        
        document.getElementById('detalleId').textContent = incidencia.id;
        document.getElementById('detalleTitulo').textContent = incidencia.titulo;
        document.getElementById('detalleEscuela').textContent = incidencia.nombre_escuela || 'Escuela desconocida';
        document.getElementById('detalleAula').textContent = incidencia.nombre_aula || 'Aula desconocida';
        document.getElementById('detalleUsuario').textContent = incidencia.nombre_usuario;
        document.getElementById('detalleFecha').textContent = incidencia.fecha_creacion;
        document.getElementById('detallePrioridad').textContent = incidencia.prioridad;
        document.getElementById('detalleEstado').textContent = incidencia.estado;
        document.getElementById('detalleDescripcion').textContent = incidencia.descripcion || 'No hay descripción';
        document.getElementById('cambiarEstado').value = incidencia.estado; 
    }

    setupModalAccessibility(modalElement) {
        modalElement.addEventListener('shown.bs.modal', () => {
            modalElement.removeAttribute('aria-hidden');
            document.body.classList.add('modal-open');
        });

        modalElement.addEventListener('hidden.bs.modal', () => {
            modalElement.setAttribute('aria-hidden', 'true');
            document.body.classList.remove('modal-open');
        });
    }

    async aplicarFiltroIncidencias() {
        const filters = {
            titulo: document.getElementById('filtroTitulo').value.trim().toLowerCase(),
            estado: document.getElementById('filtroEstado').value,
            prioridad: document.getElementById('filtroPrioridad').value,
            anio: document.getElementById('filtroAnio').value,
            usuario: document.getElementById('filtroUsuario').value.trim().toLowerCase(),
            fechaDesde: document.getElementById('filtroFechaDesde').value,
            fechaHasta: document.getElementById('filtroFechaHasta').value,
            escuelaId: document.getElementById('filtroEscuela').value
        };

        const incidencias = await this.cargarDatosIncidencias();
        const incidenciasFiltradas = incidencias.filter(incidencia => 
            this.filtrarIncidencia(incidencia, filters)
        );

        this.mostrarIncidencias(incidenciasFiltradas);
    }

    filtrarIncidencia(incidencia, filters) {
        if (filters.titulo && !(incidencia.titol || incidencia.titulo).toLowerCase().includes(filters.titulo)) {
            return false;
        }
        if (filters.estado && incidencia.estat !== filters.estado) {
            return false;
        }
        if (filters.prioridad && incidencia.prioritat !== filters.prioridad) {
            return false;
        }
        if (filters.anio) {
            const fecha = new Date(incidencia.data_incidencia);
            if (isNaN(fecha.getTime()) || fecha.getFullYear() !== parseInt(filters.anio)) {
                return false;
            }
        }
        if (filters.usuario && !incidencia.usuario_nombre.toLowerCase().includes(filters.usuario)) {
            return false;
        }
        if (filters.fechaDesde || filters.fechaHasta) {
            const fechaIncidencia = new Date(incidencia.data_incidencia);
            if (isNaN(fechaIncidencia.getTime())) {
                return false;
            }
            if (filters.fechaDesde && fechaIncidencia < new Date(filters.fechaDesde)) {
                return false;
            }
            if (filters.fechaHasta) {
                const hasta = new Date(filters.fechaHasta);
                hasta.setDate(hasta.getDate() + 1);
                if (fechaIncidencia >= hasta) {
                    return false;
                }
            }
        }
        if (filters.escuelaId) {
            const aula = this.aulas.find(a => a.id == incidencia.id_aula);
            if (!aula || aula.id_escola != filters.escuelaId) {
                return false;
            }
        }
        return true;
    }
    

    limpiarFiltro() {
        document.getElementById('formFiltroIncidencias').reset();
        this.mostrarIncidencias();
    }

    async actualizarEstadoIncidencia() {
        if (!this.incidenciaActual) return;
        
        const nuevoEstado = document.getElementById('cambiarEstado').value;
        
        try {
            const response = await fetch('../../assets/php/actualizarEstadoIncidencia.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id: this.incidenciaActual.id,
                    estado: nuevoEstado
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.incidenciaActual.estado = nuevoEstado;
                document.getElementById('detalleEstado').textContent = nuevoEstado;
                this.mostrarIncidencias();
            } else {
                throw new Error(result.message || 'Error desconocido');
            }
        } catch (error) {
            console.error(error);
            alert('Error al actualizar el estado: ' + error.message);
        }
    }

    setupEventListeners() {
        document.getElementById('btnAplicarFiltro').addEventListener('click', () => this.aplicarFiltroIncidencias());
        document.getElementById('btnLimpiarFiltro').addEventListener('click', () => this.limpiarFiltro());
        document.getElementById('btnActualizarEstado').addEventListener('click', () => this.actualizarEstadoIncidencia());
        document.getElementById('btnCerrarSesion').addEventListener('click', () => {
            localStorage.removeItem('datosCifrados');
            window.location.href = "../login.html";
        });
    }
}

// Inicialización cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    window.incidenciasManager = new IncidenciasManager();
});