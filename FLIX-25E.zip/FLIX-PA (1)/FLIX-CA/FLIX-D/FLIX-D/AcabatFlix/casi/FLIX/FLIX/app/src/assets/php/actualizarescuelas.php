<?php
require_once 'db.php';

$data = json_decode(file_get_contents('php://input'), true);

$id = $data['id'];
$nombre = $data['nom'];
$direccion = $data['direccio'];

try {
    $sql = "UPDATE escola SET nom = :nombre, direccio = :direccion WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->bindParam(':nombre', $nombre);
    $stmt->bindParam(':direccion', $direccion);
    $stmt->execute();

    echo json_encode(['success' => true,'message' => 'Escuela actualizada correctamente']);
} catch (PDOException $e) {
    echo json_encode(['success' => false ,'message' => $e->getMessage()]);
}
?>
