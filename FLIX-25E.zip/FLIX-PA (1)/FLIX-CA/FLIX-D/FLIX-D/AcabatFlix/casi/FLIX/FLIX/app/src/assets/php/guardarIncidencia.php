<?php

header("Content-Type: application/json");
require_once 'db.php'; // Conexión a la base de datos


$data = json_decode(file_get_contents("php://input"), true);
if (isset($data['titol'], $data['id_aula'], $data['descripcio'], $data['data_incidencia'], $data['estat'], $data['prioritat'], $data['id_professor'])) {
    $titol = $data['titol'];
    $id_aula = $data['id_aula'];
    $descripcio = $data['descripcio'];
    $data_incidencia = $data['data_incidencia'];
    $estat = $data['estat'];
    $prioritat = $data['prioritat'];
    $id_professor = $data['id_professor'];

    $sql = "INSERT INTO incidencia (titol, id_aula, descripcio, data_incidencia, estat, prioritat, id_usuari) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$titol, $id_aula, $descripcio, $data_incidencia, $estat, $prioritat, $id_professor]);

    if ($stmt->rowCount() === 1) {
        echo json_encode(["message" => "Incidencia guardada correctamente"]);
    } else {
        echo json_encode(["message" => "Error al guardar la incidencia"]);
    }


} else {
    echo json_encode(["message" => "Datos incompletos"]);
}





?>