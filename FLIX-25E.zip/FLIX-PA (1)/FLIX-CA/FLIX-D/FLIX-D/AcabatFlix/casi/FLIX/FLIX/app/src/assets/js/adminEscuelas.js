document.addEventListener('DOMContentLoaded', function() {
    // Verificar sesión y rol
    const textoCifradoRecuperado = localStorage.getItem('datosCifrados');
    
    if (textoCifradoRecuperado) {
        const claveCesar = 3;
        const textoDescifrado = descifrarCesar(textoCifradoRecuperado, claveCesar);
        const dataDescifrada = JSON.parse(textoDescifrado);
        
        if (dataDescifrada.rol !== "Admin App") {
            window.location.href = "../login.html";
        } else {
            cargarEscuelas();
        }
    } else {
        window.location.href = "../login.html";
    }
    
    // Evento para cerrar sesión
    document.getElementById('btnCerrarSesion').addEventListener('click', function() {
        localStorage.removeItem('datosCifrados');
        window.location.href = "../login.html";
    });
    
    // Evento para búsqueda
    document.getElementById('btnBuscarEscuela').addEventListener('click', function() {
        const busqueda = document.getElementById('busquedaEscuela').value.toLowerCase();
        filtrarEscuelas(busqueda);
    });
    
    // Evento para guardar escuela
    document.getElementById('btnGuardarEscuela').addEventListener('click', guardarEscuela);
});

function cifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) {
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65;
            return String.fromCharCode(((code - base + clave) % 26) + base);
        }
        return char;
    }).join('');
}

function descifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) {
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65;
            return String.fromCharCode(((code - base - clave + 26) % 26) + base);
        }
        return char;
    }).join('');
}

function cargarEscuelas() {
    fetch('../../assets/php/obtenerEscuelas.php')
        .then(response => {
            if (!response.ok) {
                throw new Error("Error al obtener las escuelas");
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                mostrarEscuelas(data.escuelas);
            } else {
                throw new Error(data.message || "Error al cargar las escuelas");
            }
        })
        .catch(error => {
            console.error("Error:", error);
            alert("Error al cargar las escuelas: " + error.message);
        });
}

function mostrarEscuelas(escuelas) {
    const listaEscuelas = document.getElementById('listaEscuelas');
    listaEscuelas.innerHTML = '';
    
    if (escuelas.length === 0) {
        listaEscuelas.innerHTML = '<div class="col-12 text-center py-4"><p>No hay escuelas registradas</p></div>';
        return;
    }
    
    escuelas.forEach(escuela => {
        const divEscuela = document.createElement('div');
        divEscuela.className = 'col-md-6 mb-4';
        divEscuela.innerHTML = `
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">${escuela.nom}</h5>
                    <p class="card-text"><strong>Dirección:</strong> ${escuela.direccio}</p>
                    <div class="d-flex justify-content-between">
                        <button class="btn btn-primary btn-sm" onclick="editarEscuela(${escuela.id}, '${escuela.nom}', '${escuela.direccio}')">Editar</button>
                        <button class="btn btn-danger btn-sm" onclick="eliminarEscuela(${escuela.id})">Eliminar</button>
                    </div>
                </div>
            </div>
        `;
        listaEscuelas.appendChild(divEscuela);
    });
}

function filtrarEscuelas(busqueda) {
    fetch('../../assets/php/obtenerEscuelas.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const escuelasFiltradas = data.escuelas.filter(escuela => 
                    escuela.nom.toLowerCase().includes(busqueda) || 
                    escuela.direccio.toLowerCase().includes(busqueda)
                );
                mostrarEscuelas(escuelasFiltradas);
            }
        })
        .catch(error => console.error("Error al filtrar:", error));
}

function crearEscuela() {
    document.getElementById('modalEscuelaLabel').textContent = 'Nueva Escuela';
    document.getElementById('nombreEscuela').value = '';
    document.getElementById('direccionEscuela').value = '';
    document.getElementById('modoEdicionEscuela').value = 'crear';
    
    const modal = new bootstrap.Modal(document.getElementById('modalEscuela'));
    modal.show();
}

function editarEscuela(id, nombre, direccion) {
    document.getElementById('modalEscuelaLabel').textContent = 'Editar Escuela';
    document.getElementById('nombreEscuela').value = nombre;
    document.getElementById('direccionEscuela').value = direccion;
    document.getElementById('idEscuela').value = id;
    document.getElementById('modoEdicionEscuela').value = 'editar';
    
    const modal = new bootstrap.Modal(document.getElementById('modalEscuela'));
    modal.show();
}

function guardarEscuela() {
    const modo = document.getElementById('modoEdicionEscuela').value;
    const nombre = document.getElementById('nombreEscuela').value;
    const direccion = document.getElementById('direccionEscuela').value;
    
    if (!nombre || !direccion) {
        alert('Por favor, complete todos los campos');
        return;
    }
    
    const url = modo === 'crear' ? '../../assets/php/crearEscuela.php' : '../../assets/php/actualizarEscuela.php';
    const data = {
        nombre: nombre,
        direccion: direccion
    };
    
    if (modo === 'editar') {
        data.id = document.getElementById('idEscuela').value;
    }
    
    fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            cargarEscuelas();
            const modal = bootstrap.Modal.getInstance(document.getElementById('modalEscuela'));
            modal.hide();
        } else {
            alert('Error: ' + (data.message || 'No se pudo guardar la escuela'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error al guardar la escuela');
    });
}

function eliminarEscuela(id) {
    const modalConfirmacion = new bootstrap.Modal(document.getElementById('modalPregunta'));
    modalConfirmacion.show();
    
    document.getElementById('btnConfirmarIncidencia').onclick = function() {
        fetch('../../assets/php/eliminarEscuela.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                cargarEscuelas();
            } else {
                alert('Error: ' + (data.message || 'No se pudo eliminar la escuela'));
            }
            modalConfirmacion.hide();
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al eliminar la escuela');
            modalConfirmacion.hide();
        });
    };
}