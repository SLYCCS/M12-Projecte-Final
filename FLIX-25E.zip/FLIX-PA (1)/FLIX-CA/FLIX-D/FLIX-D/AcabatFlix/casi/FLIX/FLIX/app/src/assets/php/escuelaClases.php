<?php
header("Content-Type: application/json");
require_once 'db.php'; // Conexión a la base de datos

try {
    $data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['id_escola'])) {
    echo json_encode(["success" => false, "message" => "Faltan datos"]);
    exit;
}
$stmt = $pdo->prepare("SELECT * FROM escola WHERE id = ?");
$stmt->execute([$data['id_escola']]);
$escuela = $stmt->fetchAll(PDO::FETCH_ASSOC);
$stmt = $pdo->prepare("SELECT * FROM aula WHERE id_escola = ?");
$stmt->execute([$data['id_escola']]);
$aulas = $stmt->fetchAll(PDO::FETCH_ASSOC);
$stmt = $pdo->prepare("SELECT i.* FROM incidencia i, aula a WHERE i.id_aula = a.id and a.id_escola = ?");
$stmt->execute([$data['id_escola']]);
$incidencias = $stmt->fetchAll(PDO::FETCH_ASSOC);
$escuela[0]['incidencias'] = $incidencias;
$escuela[0]['aulas'] = $aulas;
echo json_encode($escuela);

} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Error de servidor: " . $e->getMessage()]);
}


?>