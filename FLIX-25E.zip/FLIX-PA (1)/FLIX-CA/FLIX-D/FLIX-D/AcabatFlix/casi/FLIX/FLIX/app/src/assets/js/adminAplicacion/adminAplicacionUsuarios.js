// Función para cifrar un texto usando un desplazamiento (clave)
function cifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) { // Solo ciframos las letras
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65; // Para minúsculas (97) y mayúsculas (65)
            return String.fromCharCode(((code - base + clave) % 26) + base);
        }
        return char; // No ciframos otros caracteres
    }).join('');
}

// Función para descifrar un texto usando un desplazamiento (clave)
function descifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) {
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65;
            return String.fromCharCode(((code - base - clave + 26) % 26) + base); // Restamos la clave para descifrar
        }
        return char; // No desciframos otros caracteres
    }).join('');
}

// Evento para cerrar sesión
document.getElementById('btnCerrarSesion').addEventListener('click', function() {
    localStorage.removeItem('datosCifrados');
    window.location.href = "../login.html";
});

// Verificación de autenticación y rol
const textoCifradoRecuperado = localStorage.getItem('datosCifrados');
if (textoCifradoRecuperado) {
    const dataDescifrada = JSON.parse(descifrarCesar(textoCifradoRecuperado, 3));
    document.getElementById('nombreUsuarioBienvenida').innerText = dataDescifrada.nombre;
    console.log(dataDescifrada);
    
    if (dataDescifrada.tipus !== "Admin App") {
        if (dataDescifrada.tipus === "Professor") {
            window.location.href = "../profesor/profesorInicio.html";
        } else if (dataDescifrada.tipus === "Admin Escola") {
            window.location.href = "../adminEscuela/adminEscuelaInicio.html";
        }
    }
} else {
    window.location.href = "../login.html";
}

// Función para cargar usuarios desde la base de datos
async function cargarDatosUsuarios() {
    try {
        const response = await fetch('../../assets/php/usuariosAdmin.php');
        if (!response.ok) throw new Error('Error al cargar los usuarios');
        return await response.json();
    } catch (error) {
        console.error(error);
        return [];
    }
}

// Función para cargar escuelas desde la base de datos
async function cargarEscuelas() {
    try {
        const response = await fetch('../../assets/php/obtenerEscuelas.php');
        if (!response.ok) throw new Error('Error al cargar las escuelas');
        return await response.json();
    } catch (error) {
        console.error(error);
        return [];
    }
}

function formatFecha(fechaString) {
    if (!fechaString) return 'No disponible';
    const fecha = new Date(fechaString);
    return isNaN(fecha.getTime()) ? 'Fecha inválida' : fecha.toLocaleDateString('es-ES');
}

// Función para mostrar el modal de crear usuario
function mostrarModalCrearUsuario() {
    resetFormularioUsuario();
    document.getElementById('modalCrearUsuarioLabel').textContent = 'Crear Nuevo Usuario';
    document.getElementById('modoEdicionUsuario').value = 'crear';
    let selectEscuela = document.getElementById('escuelaUsuario');
    selectEscuela.disabled = false;
    selectEscuela.innerHTML = '<option value="">Seleccione una escuela</option>';
    // Ocultar campo de escuelas inicialmente
    document.getElementById('escuelaUsuarioContainer').style.display = 'none';
    
    const modal = new bootstrap.Modal(document.getElementById('modalCrearUsuario'));
    modal.show();
    
    document.getElementById('btnGuardarUsuario').onclick = () => guardarUsuario(null);
}

// Función para editar un usuario
async function editarUsuario(id) {
    const usuarios = await cargarDatosUsuarios();
    const usuario = usuarios.find(u => u.id === id);
    
    if (usuario) {
        document.getElementById('modalCrearUsuarioLabel').textContent = 'Editar Usuario';
        document.getElementById('modoEdicionUsuario').value = 'editar';
        document.getElementById('idUsuario').value = usuario.id;
        document.getElementById('nombreUsuario').value = usuario.nom;
        document.getElementById('emailUsuario').value = usuario.email;
        document.getElementById('rolUsuario').value = usuario.tipus;
        
        // Ocultar campos de contraseña en edición
        document.getElementById('passwordUsuario').required = false;
        document.getElementById('confirmarPassword').required = false;
        document.getElementById('passwordUsuario').closest('.mb-3').style.display = 'none';
        document.getElementById('confirmarPassword').closest('.mb-3').style.display = 'none';
        
        // Manejar campo de escuela
        const escuelaContainer = document.getElementById('escuelaUsuarioContainer');
        if (usuario.tipus === 'Professor' || usuario.tipus === 'Admin Escola') {
            escuelaContainer.style.display = 'block';
            const escuelas = await cargarEscuelas();
            let selectEscuela = document.getElementById('escuelaUsuario');
            selectEscuela.innerHTML = '';
            
            escuelas.forEach(escuela => {
                if (escuela.id === usuario.id_escola) {
                    console.log(escuela);
                    
                    const option = document.createElement('option');
                    option.value = escuela.id;
                    option.textContent = escuela.nom;
                    option.selected = true;
                    selectEscuela.appendChild(option);
                }
            });
            // Bloquear el select con la escuela del usuario
            selectEscuela.disabled = true;
        } else {
            escuelaContainer.style.display = 'none';
        }
        
        const modal = new bootstrap.Modal(document.getElementById('modalCrearUsuario'));
        modal.show();
        
        document.getElementById('btnGuardarUsuario').onclick = () => guardarUsuario(usuario.id);
    }
}

function resetFormularioUsuario() {
    document.getElementById('formUsuario').reset();
    document.getElementById('passwordUsuario').required = true;
    document.getElementById('confirmarPassword').required = true;
    document.getElementById('passwordUsuario').closest('.mb-3').style.display = 'block';
    document.getElementById('confirmarPassword').closest('.mb-3').style.display = 'block';
    document.getElementById('escuelaUsuarioContainer').style.display = 'none';
}

// Función para guardar un usuario
async function guardarUsuario(id) {
    const nombre = document.getElementById('nombreUsuario').value.trim();
    const email = document.getElementById('emailUsuario').value.trim();
    const rol = document.getElementById('rolUsuario').value;
    const password = document.getElementById('passwordUsuario').value;
    const confirmarPassword = document.getElementById('confirmarPassword').value;
    const modoEdicion = document.getElementById('modoEdicionUsuario').value;
    const escuelaId = (rol === 'Professor' || rol === 'Admin Escola') ? document.getElementById('escuelaUsuario').value : null;

    // Validaciones
    if (!nombre || !email || !rol) {
        alert("Todos los campos marcados con * son obligatorios.");
        return;
    }

    if ((rol === 'Professor' || rol === 'Admin Escola') && !escuelaId) {
        alert("Por favor, seleccione una escuela para este rol.");
        return;
    }

    if (modoEdicion === 'crear' && (!password || !confirmarPassword)) {
        alert("La contraseña es obligatoria para nuevos usuarios.");
        return;
    }

    if (password && password !== confirmarPassword) {
        alert("Las contraseñas no coinciden.");
        return;
    }

    const usuarioData = {
        id: id,
        nombre: nombre,
        email: email,
        rol: rol,
        password: password,
        escuela_id: escuelaId
    };

    try {
        const url = modoEdicion === 'editar' ? '../../assets/php/actualizarUsuario.php' : '../../assets/php/crearUsuario.php';
        const method = modoEdicion === 'editar' ? 'PUT' : 'POST';

        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(usuarioData)
        });

        const result = await response.json();
        
        if (result.success) {
            mostrarUsuarios();
            bootstrap.Modal.getInstance(document.getElementById('modalCrearUsuario')).hide();
        } else {
            alert('Error: ' + (result.message || 'Error desconocido'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al conectar con el servidor');
    }
}

// Función para eliminar un usuario
async function eliminarUsuario(id) {
    const modal = new bootstrap.Modal(document.getElementById('modalConfirmacion'));
    document.getElementById('modalConfirmacionLabel').textContent = 'Eliminar Usuario';
    document.getElementById('mensajeConfirmacion').textContent = '¿Estás seguro de que deseas eliminar este usuario? Esta acción no se puede deshacer.';
    
    document.getElementById('btnConfirmarAccion').onclick = async function() {
        try {
            const response = await fetch('../../assets/php/eliminarUsuario.php', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: id })
            });

            const result = await response.json();
            
            if (result.success) {
                mostrarUsuarios();
            } else {
                alert('Error al eliminar el usuario');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error al conectar con el servidor');
        }

        modal.hide();
    };

    modal.show();
}

// Función para aplicar filtros
async function aplicarFiltroUsuarios() {
    const nombre = document.getElementById('filtroNombre').value.trim().toLowerCase();
    const email = document.getElementById('filtroEmail').value.trim().toLowerCase();
    const rol = document.getElementById('filtroRol').value;
    const fechaRegistro = document.getElementById('filtroAnioRegistro').value.trim();

    const usuarios = await cargarDatosUsuarios();
    
    const usuariosFiltrados = usuarios.filter(usuario => {
        if (nombre && !usuario.nom.toLowerCase().includes(nombre)) return false;
        if (email && !usuario.email.toLowerCase().includes(email)) return false;
        if (rol && usuario.tipus !== rol) return false;
        if (fechaRegistro && new Date(usuario.data_registre).getFullYear().toString() !== fechaRegistro) return false;
        return true;
    });

    mostrarUsuarios(usuariosFiltrados);
}

// Función para mostrar usuarios
function mostrarUsuarios(usuariosFiltrados = null) {
    const listaUsuarios = document.getElementById('listaUsuarios');
    const contadorUsuarios = document.getElementById('contadorUsuarios');
    
    if (usuariosFiltrados === null) {
        cargarDatosUsuarios().then(usuarios => {
            renderizarUsuarios(usuarios);
            contadorUsuarios.textContent = `${usuarios.length} usuarios`;
        });
        return;
    }
    
    renderizarUsuarios(usuariosFiltrados);
    contadorUsuarios.textContent = `${usuariosFiltrados.length} usuarios`;
}

function renderizarUsuarios(usuarios) {
    const listaUsuarios = document.getElementById('listaUsuarios');
    listaUsuarios.innerHTML = '';

    if (!usuarios || usuarios.length === 0) {
        listaUsuarios.innerHTML = `
            <tr>
                <td colspan="6" class="text-center py-4">
                    <p class="text-muted">No se encontraron usuarios con los criterios de búsqueda.</p>
                    <button class="btn btn-primary" onclick="limpiarFiltro()">Mostrar todos</button>
                </td>
            </tr>
        `;
        return;
    }

    usuarios.forEach(usuario => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${usuario.nom}</td>
            <td>${usuario.email}</td>
            <td>${usuario.tipus}</td>
            <td>${formatFecha(usuario.data_registre)}</td>
            <td>
                <div class="d-flex gap-2">
                    <button class="btn btn-sm btn-outline-primary" onclick="editarUsuario(${usuario.id})">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="eliminarUsuario(${usuario.id})">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            </td>
        `;
        listaUsuarios.appendChild(tr);
    });
}

function limpiarFiltro() {
    document.getElementById('formFiltroUsuarios').reset();
    mostrarUsuarios();
}

// Event listeners al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    mostrarUsuarios();
    
    document.getElementById('btnAplicarFiltro').addEventListener('click', aplicarFiltroUsuarios);
    document.getElementById('btnLimpiarFiltro').addEventListener('click', limpiarFiltro);
    
    // Event listener para cambio de rol
    document.getElementById('rolUsuario').addEventListener('change', async function() {
        const escuelaContainer = document.getElementById('escuelaUsuarioContainer');
        if (this.value === 'Professor' || this.value === 'Admin Escola') {
            escuelaContainer.style.display = 'block';
            const escuelas = await cargarEscuelas();
            let selectEscuela = document.getElementById('escuelaUsuario');
            selectEscuela.innerHTML = '<option value="">Seleccione una escuela</option>';
            escuelas.forEach(escuela => {
                const option = document.createElement('option');
                option.value = escuela.id;
                option.textContent = escuela.nom;
                selectEscuela.appendChild(option);
            });
        } else {
            escuelaContainer.style.display = 'none';
        }
    });
});