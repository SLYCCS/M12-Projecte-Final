<?php
header("Content-Type: application/json");
require_once 'db.php'; // Conexión a la base de datos

// Habilitar mensajes de error
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['email']) || !isset($data['password'])) {
    echo json_encode(["success" => false, "message" => "Faltan datos"]);
    exit;
}

$email = $data['email'];
$password = $data['password'];

try {
    // Consultar el usuario desde la base de datos con email y contraseña
    $stmt = $pdo->prepare("SELECT id, nom, tipus, id_escola FROM usuari WHERE email = ? AND contrasenya = ?");
    $stmt->execute([$email, $password]); // Aquí se pasa el email y la contraseña directamente
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        echo json_encode([
            "success" => true,
            "id" => $user['id'],
            "nombre" => $user['nom'],
            "rol" => $user['tipus'],
            "id_escola" => $user['id_escola']
        ]);
    } else {
        echo json_encode(["success" => false, "message" => "Correo o contraseña incorrectos"]);
    }
} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Error de servidor: " . $e->getMessage()]);
}

?>
