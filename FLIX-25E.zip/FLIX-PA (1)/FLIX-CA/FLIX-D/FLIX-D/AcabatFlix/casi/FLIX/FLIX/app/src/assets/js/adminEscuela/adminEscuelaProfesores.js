let escuela;
let profesoresFiltrados = [];

// Función para cifrar/descifrar (igual que en el archivo inicial)
function cifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) {
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65;
            return String.fromCharCode(((code - base + clave) % 26) + base);
        }
        return char;
    }).join('');
}

function descifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) {
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65;
            return String.fromCharCode(((code - base - clave + 26) % 26) + base);
        }
        return char;
    }).join('');
}

// Verificar autenticación al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    const textoCifrado = localStorage.getItem('datosCifrados');
    
    if (textoCifrado) {
        const clave = 3;
        const textoDescifrado = descifrarCesar(textoCifrado, clave);
        const dataDescifrada = JSON.parse(textoDescifrado);
        
        if (dataDescifrada.rol === "Admin Escola") {
            escuela = dataDescifrada;
            document.getElementById('nombreUsuarioBienvenida').textContent = escuela.nombre;
            cargarProfesores();
            configurarFiltros();
        } else {
            redirigirSegunRol(dataDescifrada.rol);
        }
    } else {
        window.location.href = "../login.html";
    }
});

// Función para redirigir según el rol
function redirigirSegunRol(rol) {
    const rutas = {
        "Professor": "../profesor/profesorInicio.html",
        "Admin App": "../adminAplicacion/adminAplicacionInicio.html"
    };
    window.location.href = rutas[rol] || "../login.html";
}

// Evento para cerrar sesión
document.getElementById('btnCerrarSesion').addEventListener('click', function() {
    localStorage.removeItem('datosCifrados');
    window.location.href = "../login.html";
});

// Mostrar profesores en la interfaz
function mostrarProfesores(profesores) {
    const listaProfesores = document.getElementById('listaProfesores');
    listaProfesores.innerHTML = "";

    if (profesores.length === 0) {
        listaProfesores.innerHTML = '<div class="col-12"><p class="text-center">No se encontraron profesores</p></div>';
        return;
    }

    profesores.forEach(profesor => {
        const divProfesor = document.createElement('div');
        divProfesor.classList.add('col-md-4', 'mb-3');
        divProfesor.innerHTML = `
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">${profesor.nom}</h5>
                    <p class="card-text">Email: ${profesor.email}</p>
                </div>
                <div class="card-footer bg-transparent">
                    <button class="btn btn-sm btn-outline-primary me-2" onclick="editarProfesor('${profesor.email}')">Editar</button>
                    <button class="btn btn-sm btn-outline-danger" onclick="confirmarEliminarProfesor('${profesor.email}')">Eliminar</button>
                </div>
            </div>
        `;
        listaProfesores.appendChild(divProfesor);
    });
}

// Configurar filtros
function configurarFiltros() {
    document.getElementById('filtroNombre').addEventListener('input', aplicarFiltros);
    document.getElementById('filtroEmail').addEventListener('input', aplicarFiltros);
    document.getElementById('limpiarFiltros').addEventListener('click', limpiarFiltros);
}

// Aplicar filtros
function aplicarFiltros() {
    const filtroNombre = document.getElementById('filtroNombre').value.toLowerCase();
    const filtroEmail = document.getElementById('filtroEmail').value.toLowerCase();

    profesoresFiltrados = escuela.profesores.filter(profesor => {
        const cumpleNombre = !filtroNombre || profesor.nom.toLowerCase().includes(filtroNombre);
        const cumpleEmail = !filtroEmail || profesor.email.toLowerCase().includes(filtroEmail);
        return cumpleNombre && cumpleEmail;
    });

    mostrarProfesores(profesoresFiltrados);
}

// Variable para mantener una copia de todos los profesores
let todosLosProfesores = [];

// Modificar la función cargarProfesores para guardar ambos arrays
async function cargarProfesores() {
    try {
        const response = await fetch('../../assets/php/adminescola.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id_escola: escuela.id_escola })
        });
        
        const data = await response.json();
        todosLosProfesores = data.profesores || [];
        profesoresFiltrados = [...todosLosProfesores]; // Copia inicial
        mostrarProfesores(profesoresFiltrados);
    } catch (error) {
        console.error('Error al cargar profesores:', error);
    }
}

// Función aplicarFiltros corregida
function aplicarFiltros() {
    const filtroNombre = document.getElementById('filtroNombre').value.toLowerCase();
    const filtroEmail = document.getElementById('filtroEmail').value.toLowerCase();

    profesoresFiltrados = todosLosProfesores.filter(profesor => {
        const cumpleNombre = !filtroNombre || profesor.nom.toLowerCase().includes(filtroNombre);
        const cumpleEmail = !filtroEmail || profesor.email.toLowerCase().includes(filtroEmail);
        return cumpleNombre && cumpleEmail;
    });

    mostrarProfesores(profesoresFiltrados);
}

// Función limpiarFiltros corregida
function limpiarFiltros() {
    document.getElementById('filtroNombre').value = '';
    document.getElementById('filtroEmail').value = '';
    profesoresFiltrados = [...todosLosProfesores]; // Restaurar todos los profesores
    mostrarProfesores(profesoresFiltrados);
}

// Función para crear nuevo profesor
function crearProfesor() {
    document.getElementById('formProfesor').reset();
    document.getElementById('modoEdicionProfesor').value = 'crear';
    document.getElementById('emailProfesor').disabled = false;
    document.getElementById('modalProfesorLabel').textContent = "Añadir Nuevo Profesor";
    document.getElementById('contraseñaProfesor').value = '';
    const modal = new bootstrap.Modal(document.getElementById('modalProfesor'));
    modal.show();
}

// Función para editar profesor
function editarProfesor(email) {
    const profesor = todosLosProfesores.find(p => p.email === email);
    if (!profesor) return;

    document.getElementById('nombreProfesor').value = profesor.nom;
    document.getElementById('emailProfesor').value = profesor.email;
    document.getElementById('contraseñaProfesor').value = profesor.contrasenya || ''; // Mostrar contraseña si existe
    document.getElementById('modoEdicionProfesor').value = 'editar';
    document.getElementById('emailProfesor').disabled = true;
    document.getElementById('modalProfesorLabel').textContent = "Editar Profesor";
    const modal = new bootstrap.Modal(document.getElementById('modalProfesor'));
    modal.show();
}

document.getElementById('btnGuardarProfesor').addEventListener('click', async function() {
    const modo = document.getElementById('modoEdicionProfesor').value;
    const nombre = document.getElementById('nombreProfesor').value.trim();
    const email = document.getElementById('emailProfesor').value.trim();
    const contrasenya = document.getElementById('contraseñaProfesor').value.trim();

    // Validar campos
    if (!nombre || !email || !contrasenya) {
        alert('Por favor complete todos los campos');
        return;
    }
    // Validar email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert("Por favor, introduce un correo electrónico válido.");
        return;
    }

    const profesorData = {
        nombre,
        email,
        contrasenya,
        escuela: escuela.id_escola
    };
    try {
        const endpoint = modo === 'crear' ? 'crearProfesor.php' : 'actualizarProfesor.php';
        const response = await fetch(`../../assets/php/${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(profesorData)
        });

        const data = await response.json();
        if (data.success) {
            await cargarProfesores();
            bootstrap.Modal.getInstance(document.getElementById('modalProfesor')).hide();
        } else {
            alert(data.message || 'Error al guardar el profesor');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al conectar con el servidor');
    }
});

// Confirmar eliminación de profesor
function confirmarEliminarProfesor(email) {
    const profesor = profesoresFiltrados.find(p => p.email === email);
    if (!profesor) return;

    document.getElementById('mensajeConfirmacion').textContent = 
        `¿Estás seguro de que deseas eliminar al profesor ${profesor.nom} (${profesor.email})?`;
    
    const btnConfirmar = document.getElementById('btnConfirmarAccion');
    btnConfirmar.onclick = function() {
        eliminarProfesor(email);
    };

    const modal = new bootstrap.Modal(document.getElementById('modalPregunta'));
    modal.show();
}

// Eliminar profesor
async function eliminarProfesor(email) {
    try {
        const response = await fetch('../../assets/php/eliminarProfesor.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, escuela: escuela.id_escola })
        });

        const data = await response.json();
        if (data.success) {
            await cargarProfesores();
        } else {
            alert(data.message || 'Error al eliminar el profesor');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al conectar con el servidor');
    } finally {
        bootstrap.Modal.getInstance(document.getElementById('modalPregunta')).hide();
    }
}