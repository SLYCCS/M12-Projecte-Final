<?php
require_once 'db.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['email']) && isset($data['escuela'])) {
    $email = $data['email'];
    $escuela = $data['escuela'];

    try {
        $sql = "DELETE FROM usuari WHERE email = :email AND id_escola = :escuela";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':escuela', $escuela);

        if ($stmt->execute() && $stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Profesor eliminado correctamente']);
        } else {
            echo json_encode(['success' => false, 'message' => 'No se encontró el profesor o no se pudo eliminar']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error de conexión: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
}
?>