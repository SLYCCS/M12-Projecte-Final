<?php

header("Content-Type: application/json");
require_once 'db.php'; // Conexión a la base de datos


$query = "SELECT * FROM aula";
$result = $pdo->query($query);

if ($result->rowCount() > 0) {
    $aulas = array();
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        $aulas[] = $row;
    }
    echo json_encode($aulas);
} else {
    echo json_encode(array("message" => "No se encontraron aulas."));
}



?>