let escuela;
let todasLasIncidencias = []; // Mantendrá todas las incidencias sin filtrar
let incidenciasFiltradas = [];
let clases = [];
let profesores = [];

// Función para cifrar/descifrar
function cifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) {
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65;
            return String.fromCharCode(((code - base + clave) % 26) + base);
        }
        return char;
    }).join('');
}

function descifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) {
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65;
            return String.fromCharCode(((code - base - clave + 26) % 26) + base);
        }
        return char;
    }).join('');
}

// Verificar autenticación al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    const textoCifrado = localStorage.getItem('datosCifrados');
    
    if (textoCifrado) {
        const clave = 3;
        const textoDescifrado = descifrarCesar(textoCifrado, clave);
        const dataDescifrada = JSON.parse(textoDescifrado);
        
        if (dataDescifrada.rol === "Admin Escola") {
            escuela = dataDescifrada;
            document.getElementById('nombreUsuarioBienvenida').textContent = escuela.nombre;
            cargarDatosAdminEscuela();
        } else {
            redirigirSegunRol(dataDescifrada.rol);
        }
    } else {
        window.location.href = "../login.html";
    }
});

// Función para redirigir según el rol
function redirigirSegunRol(rol) {
    const rutas = {
        "Professor": "../profesor/profesorInicio.html",
        "Admin App": "../adminAplicacion/adminAplicacionInicio.html"
    };
    window.location.href = rutas[rol] || "../login.html";
}

// Evento para cerrar sesión
document.getElementById('btnCerrarSesion').addEventListener('click', function() {
    localStorage.removeItem('datosCifrados');
    window.location.href = "../login.html";
});

// Función para cargar datos del administrador de escuela
function cargarDatosAdminEscuela() {
    fetch('../../assets/php/adminescola.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id_escola: escuela.id_escola })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Respuesta del servidor no válida.");
        }
        return response.json();
    })
    .then(data => {
        if (!data) {
            throw new Error("La respuesta del servidor es inválida.");
        }

        clases = data.clases || [];
        profesores = data.profesores || [];
        todasLasIncidencias = data.incidencias || [];
        incidenciasFiltradas = [...todasLasIncidencias];
        
        llenarSelectClases(clases);
        mostrarIncidencias();
        configurarFiltros();
    })
    .catch(error => {
        console.error('Error al cargar los datos:', error);
        mostrarMensajeError('Error al cargar los datos. Por favor, inténtelo de nuevo.');
    });
}

// Llenar select de clases
function llenarSelectClases(clases) {
    const selectFiltro = document.getElementById('filtroClase');
    const selectModal = document.getElementById('selectClase');
    
    // Limpiar selects
    selectFiltro.innerHTML = '<option value="todas">Todas las clases</option>';
    selectModal.innerHTML = '<option value="">Seleccione una clase</option>';
    
    // Llenar con las clases disponibles
    clases.forEach(clase => {
        const optionFiltro = document.createElement('option');
        optionFiltro.value = clase.id;
        optionFiltro.textContent = clase.nom;
        selectFiltro.appendChild(optionFiltro);
        
        const optionModal = document.createElement('option');
        optionModal.value = clase.id;
        optionModal.textContent = clase.nom;
        selectModal.appendChild(optionModal);
    });
}

// Función para mostrar incidencias
function mostrarIncidencias() {
    const listaIncidencias = document.getElementById('listaIncidencias');
    if (!listaIncidencias) return;
    
    listaIncidencias.innerHTML = "";

    if (!incidenciasFiltradas || incidenciasFiltradas.length === 0) {
        listaIncidencias.innerHTML = '<div class="col-12"><p class="text-center">No se encontraron incidencias</p></div>';
        return;
    }

    incidenciasFiltradas.forEach(incidencia => {
        try {
            // Buscar la clase y profesor correspondiente con manejo de errores
            const clase = clases.find(c => c.id === incidencia.id_aula) || { nom: 'Clase no encontrada' };
            const profesor = profesores.find(p => p.id === incidencia.id_professor) || { nom: 'Profesor no encontrado' };
            console.log( incidencia);
            
            // Validar campos requeridos
            const titulo = incidencia.titol || 'Sin título';
            const fecha = incidencia.data_incidencia || 'Fecha desconocida';
            const prioridad = incidencia.prioritat || 'Desconocida';
            const estado = incidencia.estat || 'pendent';
            const descripcion = incidencia.descripcio || 'Sin descripción';
            
            // Determinar clases CSS
            const prioridadClass = getPrioridadClass(prioridad);
            const estadoClass = getEstadoClass(estado);
            
            const divIncidencia = document.createElement('div');
            divIncidencia.classList.add('col-md-4', 'mb-3');
            
            divIncidencia.innerHTML = `
                <div class="card ${prioridadClass}">
                    <div class="card-body">
                        <h5 class="card-title">${titulo}</h5>
                        <p class="card-text">Clase: ${clase.nom}</p>
                        <p class="card-text">Reportada por: ${profesor.nom}</p>
                        <p class="card-text">Fecha: ${fecha}</p>
                        <p class="card-text">Prioridad: 
                            <span class="badge ${getBadgeClass(prioridad)}">
                                ${prioridad}
                            </span>
                        </p>
                        <p class="card-text ${estadoClass}">Estado: ${estado}</p>
                        <p class="card-text">Descripción: ${descripcion}</p>
                    </div>
                    <div class="card-footer bg-transparent">
                        <button class="btn btn-sm btn-outline-primary me-2" onclick="editarIncidencia(${incidencia.id || '0'})">Editar</button>
                        <button class="btn btn-sm btn-outline-danger" onclick="confirmarEliminarIncidencia(${incidencia.id || '0'})">Eliminar</button>
                    </div>
                </div>
            `;
            listaIncidencias.appendChild(divIncidencia);
            
        } catch (error) {
            console.error('Error al mostrar incidencia:', incidencia, error);
        }
    });
}

// Funciones auxiliares para clases CSS
function getPrioridadClass(prioridad) {
    switch(prioridad.toLowerCase()) {
        case 'alta': return 'priority-high';
        case 'mitja': return 'priority-medium';
        case 'baixa': return 'priority-low';
        default: return 'priority-unknown';
    }
}

function getEstadoClass(estado) {
    switch(estado.toLowerCase()) {
        case 'pendent': return 'status-pending';
        case 'en progres': return 'status-in-progress';
        case 'resolta': return 'status-resolved';
        default: return 'status-unknown';
    }
}

function getBadgeClass(prioridad) {
    switch(prioridad.toLowerCase()) {
        case 'alta': return 'bg-danger';
        case 'mitja': return 'bg-warning text-dark';
        case 'baixa': return 'bg-success';
        default: return 'bg-secondary';
    }
}

// Configurar filtros
function configurarFiltros() {
    document.getElementById('filtroClase')?.addEventListener('change', aplicarFiltros);
    document.getElementById('filtroPrioridad')?.addEventListener('change', aplicarFiltros);
    document.getElementById('filtroEstado')?.addEventListener('change', aplicarFiltros);
    document.getElementById('limpiarFiltros')?.addEventListener('click', limpiarFiltros);
}

// Aplicar filtros
function aplicarFiltros() {
    const filtroClase = document.getElementById('filtroClase')?.value || 'todas';
    const filtroPrioridad = document.getElementById('filtroPrioridad')?.value || 'todas';
    const filtroEstado = document.getElementById('filtroEstado')?.value || 'todos';

    incidenciasFiltradas = todasLasIncidencias.filter(incidencia => {
        const cumpleClase = filtroClase === 'todas' || incidencia.id_aula == filtroClase;
        const cumplePrioridad = filtroPrioridad === 'todas' || incidencia.prioritat === filtroPrioridad;
        const cumpleEstado = filtroEstado === 'todos' || incidencia.estat === filtroEstado;
        
        return cumpleClase && cumplePrioridad && cumpleEstado;
    });

    mostrarIncidencias();
}

// Limpiar filtros
function limpiarFiltros() {
    const filtroClase = document.getElementById('filtroClase');
    const filtroPrioridad = document.getElementById('filtroPrioridad');
    const filtroEstado = document.getElementById('filtroEstado');
    
    if (filtroClase) filtroClase.value = 'todas';
    if (filtroPrioridad) filtroPrioridad.value = 'todas';
    if (filtroEstado) filtroEstado.value = 'todos';
    
    incidenciasFiltradas = [...todasLasIncidencias];
    mostrarIncidencias();
}

// Función para crear nueva incidencia
function crearIncidencia() {
    document.getElementById('formIncidencia').reset();
    document.getElementById('modoEdicionIncidencia').value = 'crear';
    document.getElementById('modalIncidenciaLabel').textContent = "Añadir Nueva Incidencia";
    // Valor por defecto para estado
    document.getElementById('estadoIncidencia').value = 'pendent';
    const modal = new bootstrap.Modal(document.getElementById('modalIncidencia'));
    modal.show();
}

// Función para editar incidencia
function editarIncidencia(id) {
    const incidencia = todasLasIncidencias.find(i => i.id === id);
    if (!incidencia) return;
    document.getElementById('tituloIncidencia').value = incidencia.titol;
    document.getElementById('selectClase').value = incidencia.id_aula;
    document.getElementById('selectTipoIncidencia').value = incidencia.prioritat;
    // Mostrar el estado actual de la incidencia, no forzar 'pendent'
    document.getElementById('estadoIncidencia').value = incidencia.estat;
    document.getElementById('descripcionIncidencia').value = incidencia.descripcio;
    document.getElementById('modoEdicionIncidencia').value = 'editar';
    document.getElementById('modalIncidenciaLabel').textContent = "Editar Incidencia";
    const modal = new bootstrap.Modal(document.getElementById('modalIncidencia'));
    modal.show();
}

// Guardar incidencia (crear o editar)
// Guardar incidencia (crear o editar)
document.getElementById('btnGuardarIncidencia').addEventListener('click', async function() {
    const modo = document.getElementById('modoEdicionIncidencia').value;
    const titulo = document.getElementById('tituloIncidencia').value.trim();
    const idClase = document.getElementById('selectClase').value;
    const prioridad = document.getElementById('selectTipoIncidencia').value;
    // Aquí está el cambio importante - no forzar 'pendent' si ya hay un valor seleccionado
    const estado = document.getElementById('estadoIncidencia').value;
    const descripcion = document.getElementById('descripcionIncidencia').value.trim();

    if (!titulo || !idClase || !prioridad || !estado || !descripcion) {
        alert('Por favor complete todos los campos');
        return;
    }

    // Si es edición, busca el id real
    let incidenciaId = null;
    if (modo === 'editar') {
        const incidencia = todasLasIncidencias.find(i => i.titol === titulo && i.id_aula == idClase);
        incidenciaId = incidencia ? incidencia.id : null;
    }

    const incidenciaData = {
        id: modo === 'editar' ? incidenciaId : null,
        titol: titulo,
        id_aula: idClase,
        prioritat: prioridad,
        // Usar el estado seleccionado, no forzar 'pendent'
        estat: estado,
        descripcio: descripcion,
        data_incidencia: new Date().toISOString().split('T')[0],
        id_professor: escuela.id
    };

    try {
        const endpoint = modo === 'crear' ? 'crearIncidencia.php' : 'actualizarIncidencia.php';
        const response = await fetch(`../../assets/php/${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(incidenciaData)
        });

        const data = await response.json();
        if (data.success) {
            await cargarDatosAdminEscuela();
            bootstrap.Modal.getInstance(document.getElementById('modalIncidencia')).hide();
        } else {
            alert(data.message || 'Error al guardar la incidencia');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al conectar con el servidor');
    }
});

// Confirmar eliminación de incidencia
function confirmarEliminarIncidencia(id) {
    const incidencia = todasLasIncidencias.find(i => i.id === id);
    if (!incidencia) return;

    document.getElementById('mensajeConfirmacion').textContent =
        `¿Estás seguro de que deseas eliminar la incidencia "${incidencia.titol}"?`;

    const btnConfirmar = document.getElementById('btnConfirmarAccion');
    btnConfirmar.onclick = function() {
        eliminarIncidencia(id);
    };

    const modal = new bootstrap.Modal(document.getElementById('modalPregunta'));
    modal.show();
}

// Eliminar incidencia
async function eliminarIncidencia(id) {
    try {
        const response = await fetch('../../assets/php/eliminarIncidencia.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id })
        });

        const data = await response.json();
        if (data.success) {
            await cargarDatosAdminEscuela();
        } else {
            alert(data.message || 'Error al eliminar la incidencia');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al conectar con el servidor');
    } finally {
        bootstrap.Modal.getInstance(document.getElementById('modalPregunta')).hide();
    }
}

// Función para mostrar mensajes de error
function mostrarMensajeError(mensaje) {
    const listaIncidencias = document.getElementById('listaIncidencias');
    if (listaIncidencias) {
        listaIncidencias.innerHTML = `
            <div class="col-12">
                <div class="alert alert-danger" role="alert">
                    ${mensaje}
                </div>
            </div>
        `;
    }
}