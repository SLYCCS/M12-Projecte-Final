let escuela;
let clasesFiltradas = [];
let todasLasClases = [];
// Función para cifrar/descifrar (igual que en el archivo inicial)
function cifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) {
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65;
            return String.fromCharCode(((code - base + clave) % 26) + base);
        }
        return char;
    }).join('');
}

function descifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) {
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65;
            return String.fromCharCode(((code - base - clave + 26) % 26) + base);
        }
        return char;
    }).join('');
}

// Verificar autenticación al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    const textoCifrado = localStorage.getItem('datosCifrados');
    
    if (textoCifrado) {
        const clave = 3;
        const textoDescifrado = descifrarCesar(textoCifrado, clave);
        const dataDescifrada = JSON.parse(textoDescifrado);
        
        if (dataDescifrada.rol === "Admin Escola") {
            escuela = dataDescifrada;
            document.getElementById('nombreUsuarioBienvenida').textContent = escuela.nombre;
            cargarClases();
            configurarFiltros();
        } else {
            redirigirSegunRol(dataDescifrada.rol);
        }
    } else {
        window.location.href = "../login.html";
    }
});

// Función para redirigir según el rol
function redirigirSegunRol(rol) {
    const rutas = {
        "Professor": "../profesor/profesorInicio.html",
        "Admin App": "../adminAplicacion/adminAplicacionInicio.html"
    };
    window.location.href = rutas[rol] || "../login.html";
}

// Evento para cerrar sesión
document.getElementById('btnCerrarSesion').addEventListener('click', function() {
    localStorage.removeItem('datosCifrados');
    window.location.href = "../login.html";
});

// Cargar clases
async function cargarClases() {
    try {
        const response = await fetch('../../assets/php/adminescola.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id_escola: escuela.id_escola })
        });
        
        const data = await response.json();
        clasesFiltradas = data.clases || [];
        mostrarClases(clasesFiltradas);
    } catch (error) {
        console.error('Error al cargar clases:', error);
    }
}

// Mostrar clases en la interfaz
function mostrarClases(clases) {
    const listaClases = document.getElementById('listaClases');
    listaClases.innerHTML = "";

    if (clases.length === 0) {
        listaClases.innerHTML = '<div class="col-12"><p class="text-center">No se encontraron clases</p></div>';
        return;
    }

    clases.forEach(clase => {
        const divClase = document.createElement('div');
        divClase.classList.add('col-md-4', 'mb-3');
        divClase.innerHTML = `
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">${clase.nom}</h5>
                    <div class="mb-3">
                        <span class="badge bg-primary equipment-badge">Mesas: ${clase.num_mesas}</span>
                        <span class="badge bg-primary equipment-badge">Sillas: ${clase.num_sillas}</span>
                        <span class="badge bg-success equipment-badge">Ordenadores: ${clase.num_ordenadores}</span>
                        <span class="badge bg-info equipment-badge">Pantallas: ${clase.num_monitores}</span>
                        <span class="badge bg-warning equipment-badge">Teclados: ${clase.num_teclados}</span>
                        <span class="badge bg-danger equipment-badge">Ratones: ${clase.num_ratones}</span>
                    </div>
                </div>
                <div class="card-footer bg-transparent">
                    <button class="btn btn-sm btn-outline-primary me-2" onclick="editarClase(${clase.id})">Editar</button>
                    <button class="btn btn-sm btn-outline-danger" onclick="confirmarEliminarClase(${clase.id})">Eliminar</button>
                </div>
            </div>
        `;
        listaClases.appendChild(divClase);
    });
}

// Configurar filtros
function configurarFiltros() {
    document.getElementById('filtroNombre').addEventListener('input', aplicarFiltros);
    document.getElementById('filtroEquipamiento').addEventListener('change', aplicarFiltros);
    document.getElementById('limpiarFiltros').addEventListener('click', limpiarFiltros);
}

// Función para crear nueva clase
function crearClase() {
    document.getElementById('formClase').reset();
    document.getElementById('modoEdicionClase').value = 'crear';
    document.getElementById('idClase').value = ''; // input oculto vacío
    document.getElementById('modalClaseLabel').textContent = "Añadir Nueva Clase";
    const modal = new bootstrap.Modal(document.getElementById('modalClase'));
    modal.show();
}

function editarClase(id) {
    const clase = clasesFiltradas.find(c => c.id === Number(id));
    if (!clase) return;
    document.getElementById('nombreClase').value = clase.nom;
    document.getElementById('mesasClase').value = clase.num_mesas;
    document.getElementById('sillasClase').value = clase.num_sillas;
    document.getElementById('ordenadoresClase').value = clase.num_ordenadores;
    document.getElementById('pantallasClase').value = clase.num_monitores;
    document.getElementById('tecladosClase').value = clase.num_teclados;
    document.getElementById('ratonesClase').value = clase.num_ratones;
    document.getElementById('modoEdicionClase').value = 'editar';
    document.getElementById('idClase').value = clase.id; // input oculto
    const modal = new bootstrap.Modal(document.getElementById('modalClase'));
    modal.show();
}

// Guardar clase (crear o editar)
// ...existing code...
// Guardar clase (crear o editar)
document.getElementById('btnGuardarClase').onclick = async function() {
    const modo = document.getElementById('modoEdicionClase').value;
    const nombre = document.getElementById('nombreClase').value.trim();
    const mesas = parseInt(document.getElementById('mesasClase').value);
    const sillas = parseInt(document.getElementById('sillasClase').value);
    const ordenadores = parseInt(document.getElementById('ordenadoresClase').value);
    const pantallas = parseInt(document.getElementById('pantallasClase').value);
    const teclados = parseInt(document.getElementById('tecladosClase').value);
    const ratones = parseInt(document.getElementById('ratonesClase').value);

    if (!nombre || isNaN(mesas) || isNaN(sillas) || isNaN(ordenadores) || 
        isNaN(pantallas) || isNaN(teclados) || isNaN(ratones)) {
        alert('Por favor complete todos los campos con valores válidos');
        return;
    }

    // Validación de nombre único SOLO al crear
    if (modo === 'crear') {
        const nombreNormalizado = nombre.toLowerCase().replace(/\s+/g, '');
        const existe = todasLasClases.some(clase => 
            clase.nom.toLowerCase().replace(/\s+/g, '') === nombreNormalizado
        );
        if (existe) {
            alert('Ya existe una clase con ese nombre en la escuela.');
            return;
        }
    }

    // Construir objeto de datos
    const claseData = {
        nombre,
        num_mesas: mesas,
        num_sillas: sillas,
        num_ordenadores: ordenadores,
        num_monitores: pantallas,
        num_teclados: teclados,
        num_ratones: ratones,
        escuela: escuela.id_escola
    };

    if (modo === 'editar') {
        claseData.id = Number(document.getElementById('idClase').value);
    }

    try {
        const endpoint = modo === 'crear' ? 'crearClase.php' : 'actualizarClase.php';
        const response = await fetch(`../../assets/php/${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(claseData)
        });

        const data = await response.json();
        if (data.success) {
            await cargarClases();
            bootstrap.Modal.getInstance(document.getElementById('modalClase')).hide();
        } else {
            alert(data.message || 'Error al guardar la clase');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al conectar con el servidor');
    }
};
// ...existing code...

// Confirmar eliminación de clase
function confirmarEliminarClase(id) {
    const clase = clasesFiltradas.find(c => c.id === Number(id));
    if (!clase) return;

    document.getElementById('mensajeConfirmacion').textContent = 
        `¿Estás seguro de que deseas eliminar la clase ${clase.nom}?`;
    
    const btnConfirmar = document.getElementById('btnConfirmarAccion');
    btnConfirmar.onclick = function() {
        eliminarClase(id);
    };

    const modal = new bootstrap.Modal(document.getElementById('modalPregunta'));
    modal.show();
}

// Eliminar clase
async function eliminarClase(id) {
    try {
        const response = await fetch('../../assets/php/eliminarClase.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: Number(id), escuela: escuela.id_escola })
        });

        const data = await response.json();
        if (data.success) {
            await cargarClases();
        } else {
            alert(data.message || 'Error al eliminar la clase');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al conectar con el servidor');
    } finally {
        bootstrap.Modal.getInstance(document.getElementById('modalPregunta')).hide();
    }
}
 // Mantendrá todas las clases sin filtrar
// [El resto de tus funciones de cifrado/descifrado y autenticación se mantienen igual...]

// Cargar clases - Función modificada
async function cargarClases() {
    try {
        const response = await fetch('../../assets/php/adminescola.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id_escola: escuela.id_escola })
        });
        
        const data = await response.json();
        todasLasClases = data.clases || [];
        clasesFiltradas = [...todasLasClases]; // Copia inicial
        mostrarClases(clasesFiltradas);
    } catch (error) {
        console.error('Error al cargar clases:', error);
    }
}

// Aplicar filtros - Función corregida
function aplicarFiltros() {
    const filtroNombre = document.getElementById('filtroNombre').value.toLowerCase();
    const filtroEquipamiento = document.getElementById('filtroEquipamiento').value;

    clasesFiltradas = todasLasClases.filter(clase => {
        const cumpleNombre = !filtroNombre || clase.nom.toLowerCase().includes(filtroNombre);
        
        let cumpleEquipamiento = true;
        if (filtroEquipamiento !== 'todos') {
            switch(filtroEquipamiento) {
                case 'ordenadores': 
                    cumpleEquipamiento = clase.num_ordenadores > 0; 
                    break;
                case 'pantallas': 
                    cumpleEquipamiento = clase.num_monitores > 0; 
                    break;
                case 'mesas': 
                    cumpleEquipamiento = clase.num_mesas > 0; 
                    break;
                case 'sillas': 
                    cumpleEquipamiento = clase.num_sillas > 0; 
                    break;
                // Puedes añadir más casos según necesites
            }
        }
        
        return cumpleNombre && cumpleEquipamiento;
    });

    mostrarClases(clasesFiltradas);
}

// Limpiar filtros - Función corregida
function limpiarFiltros() {
    document.getElementById('filtroNombre').value = '';
    document.getElementById('filtroEquipamiento').value = 'todos';
    clasesFiltradas = [...todasLasClases]; // Restaurar todas las clases
    mostrarClases(clasesFiltradas);
}
