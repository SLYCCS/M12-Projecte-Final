<?php
require_once 'db.php';
header('Content-Type: application/json');
try {
    $stmt = $pdo->query('
        SELECT u.*, e.nom AS escuela 
        FROM usuari u
        LEFT JOIN escola e ON u.id_escola = e.id
    ');
    $usuaris = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($usuaris);
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
}
?>