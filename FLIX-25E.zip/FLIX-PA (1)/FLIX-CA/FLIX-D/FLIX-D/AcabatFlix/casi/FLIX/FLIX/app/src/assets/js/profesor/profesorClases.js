let escuela;
let clasesFiltradas = [];

// Función para cifrar un texto usando un desplazamiento (clave)
function cifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) { // Solo ciframos las letras
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65; // Para minúsculas (97) y mayúsculas (65)
            return String.fromCharCode(((code - base + clave) % 26) + base);
        }
        return char; // No ciframos otros caracteres
    }).join('');
}

// Función para descifrar un texto usando un desplazamiento (clave)
function descifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) {
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65;
            return String.fromCharCode(((code - base - clave + 26) % 26) + base); // Restamos la clave para descifrar
        }
        return char; // No desciframos otros caracteres
    }).join('');
}

// Verificar si el usuario está logueado al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    const textoCifradoRecuperado = localStorage.getItem('datosCifrados');
    
    if (textoCifradoRecuperado) {
        const claveCesar = 3; // Usar la misma clave para el descifrado
        const textoDescifrado = descifrarCesar(textoCifradoRecuperado, claveCesar);
        dataDescifrada = JSON.parse(textoDescifrado);
        
        if (dataDescifrada.rol === "Professor") {
            console.log('Rol correcto');
            cargarClasesProfesor();
            configurarFiltros();
        } else {
            // Redirigir si no es profesor
            window.location.href = dataDescifrada.rol === "Admin App" 
                ? "../adminAplicacion/adminAplicacionInicio.html" 
                : "../adminEscuela/adminEscuelaInicio.html";
        }
    } else {
        window.location.href = "../login.html";
    }
});

// Evento para cerrar sesión
document.getElementById('btnCerrarSesion').addEventListener('click', function() {
    localStorage.removeItem('datosCifrados');
    window.location.href = "../login.html";
});
// Función para cargar las clases del profesor
async function cargarClasesProfesor() {
    try {
        // Mostrar el nombre del profesor
        const nombreProfesorElement = document.getElementById('nombreUsuarioBienvenida');
        if (nombreProfesorElement) {
            nombreProfesorElement.textContent = dataDescifrada.nombre;
        }

        // Obtener datos de la escuela y sus aulas
        const response = await fetch('../../assets/php/escuelaClases.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id_escola: dataDescifrada.id_escola })
        });

        const data = await response.json();
        escuela = data[0] || {};
        clasesFiltradas = escuela.aulas || [];

        // Mostrar todas las clases inicialmente
        mostrarClases(clasesFiltradas);
        
    } catch (error) {
        console.error('Error al cargar las clases:', error);
    }
}

// Función para mostrar las clases en la página
function mostrarClases(clases) {
    const listaClases = document.getElementById('listaClases');
    listaClases.innerHTML = ""; // Limpiar contenido previo

    if (clases.length === 0) {
        listaClases.innerHTML = '<div class="col-12"><p class="text-center">No se encontraron clases</p></div>';
        return;
    }

    clases.forEach(clase => {
        const divClase = document.createElement('div');
        divClase.classList.add('col-md-4');
        
        divClase.innerHTML = `
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">${clase.nom}</h5>
                    <div class="mb-3">
                        <span class="badge bg-primary equipment-badge">Mesas: ${clase.num_mesas}</span>
                        <span class="badge bg-primary equipment-badge">Sillas: ${clase.num_sillas}</span>
                        <span class="badge bg-success equipment-badge">Ordenadores: ${clase.num_ordenadores}</span>
                        <span class="badge bg-info equipment-badge">Pantallas: ${clase.num_monitores}</span>
                        <span class="badge bg-warning equipment-badge">Teclados: ${clase.num_teclados}</span>
                        <span class="badge bg-danger equipment-badge">Ratones: ${clase.num_ratones}</span>
                    </div>
                </div>
                <div class="card-footer bg-transparent">
                    <button class="btn btn-sm btn-outline-primary me-2" onclick="editarClase(${clase.id})">Editar</button>
                </div>
            </div>
        `;
        listaClases.appendChild(divClase);
    });
}
// Mostrar modal de confirmación antes de guardar cambios al editar una clase
function mostrarModalPregunta(callback) {
    const modalPregunta = new bootstrap.Modal(document.getElementById('modalPregunta'));
    const btnConfirmar = document.getElementById('btnConfirmarIncidencia');

    // Limpiar eventos previos
    btnConfirmar.onclick = null;

    btnConfirmar.onclick = function() {
        modalPregunta.hide();
        callback();
    };

    modalPregunta.show();
}

// Modificar la función editarClase para usar el modal de confirmación
const originalEditarClase = editarClase;
editarClase = function(id) {
    modoEdicionClase = true;
    originalEditarClase(id);

    // Cambiar el botón guardar para mostrar el modal de pregunta antes de guardar
    document.getElementById('btnGuardarClase').onclick = function() {
        mostrarModalPregunta(() => guardarClase(id));
    };
};
// Configurar los filtros
function configurarFiltros() {
    // Filtro por nombre
    document.getElementById('filtroNombre').addEventListener('input', function() {
        aplicarFiltros();
    });
    
    // Filtro por equipamiento
    document.getElementById('filtroEquipamiento').addEventListener('change', function() {
        aplicarFiltros();
    });
    
    // Botón para limpiar filtros
    document.getElementById('limpiarFiltros').addEventListener('click', function() {
        document.getElementById('filtroNombre').value = '';
        document.getElementById('filtroEquipamiento').value = 'todos';
        aplicarFiltros();
    });
}

// Aplicar todos los filtros seleccionados
function aplicarFiltros() {
    const filtroNombre = document.getElementById('filtroNombre').value.toLowerCase();
    const filtroEquipamiento = document.getElementById('filtroEquipamiento').value;
    
    clasesFiltradas = escuela.aulas.filter(clase => {
        // Filtro por nombre
        if (filtroNombre && !clase.nom.toLowerCase().includes(filtroNombre)) {
            return false;
        }
        
        // Filtro por equipamiento
        if (filtroEquipamiento !== 'todos') {
            switch(filtroEquipamiento) {
                case 'mesas': if (clase.num_mesas <= 0) return false; break;
                case 'sillas': if (clase.num_sillas <= 0) return false; break;
                case 'ordenadores': if (clase.num_ordenadores <= 0) return false; break;
                case 'pantallas': if (clase.num_monitores <= 0) return false; break;
                case 'teclados': if (clase.num_teclados <= 0) return false; break;
                case 'ratones': if (clase.num_ratones <= 0) return false; break;
            }
        }
        
        return true;
    });
    
    mostrarClases(clasesFiltradas);
}

let modoEdicionClase = false; // Variable global para saber si es edición o alta

function editarClase(id) {
    const clase = escuela.aulas.find(aula => aula.id === id);
    if (!clase) return;

    modoEdicionClase = true; // Indicamos que es edición

    // Llenar el modal con los datos de la clase
    document.getElementById('nombreClase').value = clase.nom;
    document.getElementById('mesasClase').value = clase.num_mesas;
    document.getElementById('sillasClase').value = clase.num_sillas;
    document.getElementById('ordenadoresClase').value = clase.num_ordenadores;
    document.getElementById('pantallasClase').value = clase.num_monitores;
    document.getElementById('tecladosClase').value = clase.num_teclados;
    document.getElementById('ratonesClase').value = clase.num_ratones;

    // Cambiar el título del modal
    document.getElementById('modalClaseLabel').textContent = "Editar Clase";

    // Configurar el botón de guardar para edición
    document.getElementById('btnGuardarClase').onclick = function() {
        guardarClase(id);
    };

    // Mostrar el modal
    const modalClase = new bootstrap.Modal(document.getElementById('modalClase'));
    modalClase.show();
}
document.getElementById('modalClase').addEventListener('hidden.bs.modal', function() {
    modoEdicionClase = false;
});
// Función para guardar una clase (nueva o editada)
async function guardarClase(id) {
    const nombre = document.getElementById('nombreClase').value;
    const mesas = document.getElementById('mesasClase').value;
    const sillas = document.getElementById('sillasClase').value;
    const ordenadores = document.getElementById('ordenadoresClase').value;
    const pantallas = document.getElementById('pantallasClase').value;
    const teclados = document.getElementById('tecladosClase').value;
    const ratones = document.getElementById('ratonesClase').value;

    // Validar los campos
    if (!nombre || mesas < 0 || sillas < 0 || ordenadores < 0 || pantallas < 0 || teclados < 0 || ratones < 0) {
        alert("Por favor, complete todos los campos con valores válidos.");
        return;
    }

    const clase = {
        id: id,
        nom: nombre,
        num_mesas: mesas,
        num_sillas: sillas,
        num_ordenadores: ordenadores,
        num_monitores: pantallas,
        num_teclados: teclados,
        num_ratones: ratones,
        id_escola: dataDescifrada.id_escola
    };

    try {
        const response = await fetch('../../assets/php/guardarClase.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(clase)
        });

        const result = await response.json();
        if (result.success) {
            // Recargar las clases
            await cargarClasesProfesor();
            
            // Cerrar el modal
            const modalClase = bootstrap.Modal.getInstance(document.getElementById('modalClase'));
            modalClase.hide();
        } else {
            alert("Error al guardar la clase: " + (result.message || "Error desconocido"));
        }
    } catch (error) {
        console.error('Error al guardar la clase:', error);
        alert("Error al conectar con el servidor");
    }
}

// Función para eliminar una clase
async function eliminarClase(id) {
    if (!confirm("¿Estás seguro de que quieres eliminar esta clase? Esta acción no se puede deshacer.")) {
        return;
    }

    try {
        const response = await fetch('../../assets/php/eliminarClase.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id })
        });

        const result = await response.json();
        if (result.success) {
            // Recargar las clases
            await cargarClasesProfesor();
        } else {
            alert("Error al eliminar la clase: " + (result.message || "Error desconocido"));
        }
    } catch (error) {
        console.error('Error al eliminar la clase:', error);
        alert("Error al conectar con el servidor");
    }
}
