let escuela;
let clases;

// Función para cifrar un texto usando un desplazamiento (clave)
function cifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) { // Solo ciframos las letras
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65; // Para minúsculas (97) y mayúsculas (65)
            return String.fromCharCode(((code - base + clave) % 26) + base);
        }
        return char; // No ciframos otros caracteres
    }).join('');
}

// Función para descifrar un texto usando un desplazamiento (clave)
function descifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) {
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65;
            return String.fromCharCode(((code - base - clave + 26) % 26) + base); // Restamos la clave para descifrar
        }
        return char; // No desciframos otros caracteres
    }).join('');
}

// Recuperar los datos cifrados desde localStorage
const textoCifradoRecuperado = localStorage.getItem('datosCifrados');
// Función para verificar si el usuario está logueado al cargar la página
if (textoCifradoRecuperado) {
    const claveCesar = 3; // Usar la misma clave para el descifrado

    // Descifrar los datos
    const textoDescifrado = descifrarCesar(textoCifradoRecuperado, claveCesar);

    // Convertir el texto descifrado de vuelta al objeto
    dataDescifrada = JSON.parse(textoDescifrado);

    console.log('Datos descifrados:', dataDescifrada);
    if (dataDescifrada.rol === "Professor") {
        console.log('Rol correcto');
        cargarDatosProfesor();
    } else if (dataDescifrada.rol === "Admin App") {
        window.location.href = "../adminAplicacion/adminAplicacionInicio.html";
    } else if (dataDescifrada.rol === "Admin Escola") {
        window.location.href = "../adminEscuela/adminEscuelaInicio.html";
    }
} else {
    window.location.href = "../login.html"; // Redirigir al login si no hay datos cifrados
}
// Evento para cerrar sesión
document.getElementById('btnCerrarSesion').addEventListener('click', function() {
    // Eliminar usuario y escuela del localStorage
    localStorage.removeItem('datosCifrados');
    
    // Redirigir a la página de login
    window.location.href = "../login.html";
});
// Función para cargar los datos del profesor
async function cargarDatosProfesor() {
    try {
        // Mostrar el nombre del profesor
        listaClases.innerHTML = ""; // Limpiar cualquier contenido previo
        const nombreProfesorElement = document.getElementById('nombreUsuarioBienvenida');
        if (nombreProfesorElement) {
            nombreProfesorElement.textContent = dataDescifrada.nombre;
        } else {
            console.error('Elemento con ID "nombreProfesor" no encontrado.');
        }
        console.log('Cargando los datos de la escuela...');
        
        const response = await fetch('../../assets/php/escuelaClases.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id_escola: dataDescifrada.id_escola })
        });

        const data = await response.json();
        console.log('Datos recibidos:', data); // Verificar que los datos se recibieron correctamente

        escuela = data[0] || {}; // Asegurarse de que no sea undefined
        console.log('Escuela cargada:', escuela);

        if (!escuela.aulas || escuela.aulas.length === 0) {
            console.warn(`La escuela ${escuela.nom || "desconocida"} no tiene aulas registradas.`);
            return;
        }

        // Iterar sobre las aulas dentro de cada escuela
        escuela.aulas.forEach((aula) => {
            const divAula = document.createElement('div');
            divAula.classList.add('col-md-4', 'mb-3');

            divAula.innerHTML = `
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">${aula.nom}</h5>
                        <p class="card-text">Mesas: ${aula.num_mesas}</p>
                        <p class="card-text">Sillas: ${aula.num_sillas}</p>
                        <p class="card-text">Teclados: ${aula.num_teclados}</p>
                        <p class="card-text">Ratones: ${aula.num_ratones}</p>
                        <p class="card-text">Pantallas: ${aula.num_monitores}</p>
                        <p class="card-text">Ordenadores: ${aula.num_ordenadores}</p>
                        <button class="btn btn-secondary" onclick="EditarClase(${aula.id})">Editar</button>
                    </div>
                </div>
            `;
            listaClases.appendChild(divAula);
        });

        // Cargar incidencias asociadas
        const listaIncidencias = document.getElementById('listaIncidencias');
        listaIncidencias.innerHTML = ""; // Limpiar cualquier contenido previo

        escuela.incidencias.forEach(incidencia => {
            const claseIncidencia = escuela.aulas.find(aula => aula.id === incidencia.id_aula);
            const nombreClaseIncidencia = claseIncidencia ? claseIncidencia.nom : 'Clase desconocida';
            const divIncidencia = document.createElement('div');
            divIncidencia.classList.add('col-md-4', 'mb-3');
            divIncidencia.innerHTML = `
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Incidencia: ${incidencia.titol}</h5>
                        <p class="card-text" id = ${incidencia.id_aula}>Clase: ${nombreClaseIncidencia}</p>
                        <p class="card-text">Fecha: ${incidencia.data_incidencia}</p>
                        <p class="card-text">Relevancia: ${incidencia.prioritat}</p>
                        <p class="card-text">Estado: ${incidencia.estat}</p>
                        <p class="card-text">Descripción: ${incidencia.descripcio}</p>
                    </div>
                </div>
            `;
            listaIncidencias.appendChild(divIncidencia);
        });

        // Llenar el select del modal con las clases
        if (escuela.aulas) {
            console.log('Aulas disponibles:', escuela.aulas);
            llenarSelectClases(escuela.aulas);
        } else {
            console.error('No se encontraron aulas en la escuela');
        }
    } catch (error) {
        console.error('Error al cargar los datos del profesor:', error);
    }
}



// Función para guardar una clase
async function guardarClase(id) {
    const nombre = document.getElementById('nombreClase').value;
    const mesas = document.getElementById('mesasClase').value;
    const sillas = document.getElementById('sillasClase').value;
    const teclados = document.getElementById('tecladosClase').value;
    const pantallas = document.getElementById('pantallasClase').value;
    const ordenadores = document.getElementById('ordenadoresClase').value;
    const ratones = document.getElementById('ratonesClase').value;

    // Validar los campos
    if (nombre === "" || mesas === "" || sillas === "" || teclados === "" || pantallas === "" || ordenadores === "" || ratones === "") {
        alert("Todos los campos son obligatorios.");
        return;
    }

    // Crear el objeto de la clase
    const clase = {
        id: id,
        nom: nombre,
        num_mesas: mesas,
        num_sillas: sillas,
        num_teclados: teclados,
        num_monitores: pantallas,
        num_ordenadores: ordenadores,
        num_ratones: ratones
    };
    try {
        await fetch(`../../assets/php/guardarClase.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(clase)
        });
        
        // Recargar los datos del profesor
        cargarDatosProfesor();

        $('#modalClase').modal('hide'); // Ocultar modal
    } catch (error) {
        console.error('Error al guardar la clase:', error);
    }
}

// Función para llenar el select del modal con las clases
function llenarSelectClases(clases) {
    const selectClases = document.getElementById('selectClase');
    selectClases.innerHTML = ""; // Limpiar cualquier contenido previo
    console.log(clases);
    
    clases.forEach(clase => {
        const option = document.createElement('option');
        option.value = clase.id; // Usar el id de la clase como valor
        option.textContent = clase.nom; // Usar el nombre de la clase como texto
        selectClases.appendChild(option);
    });
}

// Función para ver detalles de una clase (para agregar/modificar ítems)
function EditarClase(id) {
    
            const clase = escuela.aulas.find(aula => aula.id === id);
            console.log(clase);
            // Mostrar el nombre de la clase en el modal
            document.getElementById('nombreClase').value = clase.nom;
            // Mostrar los ítems de la clase en el modal
            document.getElementById('mesasClase').value = clase.num_mesas;
            document.getElementById('sillasClase').value = clase.num_sillas;
            document.getElementById('tecladosClase').value = clase.num_teclados;
            document.getElementById('pantallasClase').value = clase.num_monitores;
            document.getElementById('ordenadoresClase').value = clase.num_ordenadores;
            document.getElementById('ratonesClase').value = clase.num_ratones;

            // Asignar el evento al botón de guardar 
            document.getElementById('btnGuardarClase').onclick = () => guardarClase(clase.id);
            // Mostrar el modal después de actualizar los elementos
            const modalClase = new bootstrap.Modal(document.getElementById('modalClase'));
            modalClase.show();
}

// Evento para crear incidencia
// Manejo del botón para guardar incidencia
document.getElementById('btnGuardarIncidencia').addEventListener('click', function () {
    // Validar campos del formulario
    const descripcion = document.getElementById('descripcionIncidencia').value.trim();

    if (descripcion === "") {
        alert("La descripción no puede estar vacía.");
        return;
    }

    // Cerrar el modal de incidencia
    const modalIncidencia = bootstrap.Modal.getInstance(document.getElementById('modalIncidencia'));
    modalIncidencia.hide();

    // Esperar hasta que se cierre completamente y luego abrir el modal de confirmación
    const modalPregunta = new bootstrap.Modal(document.getElementById('modalPregunta'));
    document.getElementById('modalIncidencia').addEventListener('hidden.bs.modal', function () {
        modalPregunta.show();
    }, { once: true });
});

// Manejo de la confirmación en el segundo modal
document.getElementById('btnConfirmarIncidencia').addEventListener('click', async function () {
    const descripcion = document.getElementById('descripcionIncidencia').value.trim();

    const claseSeleccionada = document.getElementById('selectClase').value;
    let nombreClaseIncidencia = document.getElementById(claseSeleccionada).id;
    nombreClaseIncidencia = parseInt(nombreClaseIncidencia);
    let tituloClaseIncidencia = document.getElementById('tituloIncidencia').value;
    
    const relevanciaSeleccionada = document.getElementById('selectTipoIncidencia').value;
    const usuarioAutenticado = dataDescifrada.id;

    // Crear nueva incidencia
    const nuevaIncidencia = {
        titol: tituloClaseIncidencia,
        id_aula: nombreClaseIncidencia,
        descripcio: descripcion,
        data_incidencia: new Date().toISOString().split('T')[0], // Fecha actual en formato YYYY-MM-DD
        estat: "Pendent",
        prioritat: relevanciaSeleccionada,
        id_professor: usuarioAutenticado
    };

    console.log('Nueva incidencia:', nuevaIncidencia);
    
    try {
        await fetch(`../../assets/php/guardarIncidencia.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(nuevaIncidencia)
        });

        // Recargar las incidencias en la página
        cargarDatosProfesor();

        // Cerrar el modal de confirmación y limpiar el backdrop si es necesario
        const modalPregunta = bootstrap.Modal.getInstance(document.getElementById('modalPregunta'));
        modalPregunta.hide();

        // Asegurarse de que el backdrop desaparezca completamente
        document.getElementById('modalPregunta').addEventListener('hidden.bs.modal', function () {
            const backdrop = document.querySelector('.modal-backdrop');
            if (backdrop) {
                backdrop.remove(); // Eliminar el backdrop manualmente si persiste
            }

            document.body.classList.remove('modal-open'); // Eliminar la clase que bloquea el scroll
            document.body.style.paddingRight = ''; // Restaurar el padding si se agregó
        }, { once: true });
    } catch (error) {
        console.error('Error al guardar la incidencia:', error);
    }
});
