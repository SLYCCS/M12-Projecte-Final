
CREATE DATABASE IF NOT EXISTS FLIX;
USE FLIX;

-- Tabla Escola (Escuelas)
CREATE TABLE Escola (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    direccio VARCHAR(255) NOT NULL,
    data_creacio TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla Aula (Aulas dentro de una escuela, con periféricos)
CREATE TABLE Aula (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    id_escola INT NOT NULL,
    num_sillas INT NOT NULL CHECK (num_sillas >= 0),
    num_mesas INT NOT NULL CHECK (num_mesas >= 0),
    num_teclados INT NOT NULL CHECK (num_teclados >= 0),
    num_ratones INT NOT NULL CHECK (num_ratones >= 0),
    num_monitores INT NOT NULL CHECK (num_monitores >= 0),
    num_ordenadores INT NOT NULL CHECK (num_ordenadores >= 0),
    FOREIGN KEY (id_escola) REFERENCES Escola(id) ON DELETE CASCADE
);

-- Tabla Usuari (Usuarios en la escuela)
CREATE TABLE Usuari (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    tipus ENUM('Professor', 'Admin Escola', 'Admin App') NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    contrasenya VARCHAR(255) NOT NULL,
    assignatura VARCHAR(100),
    id_escola INT NOT NULL,
    data_registre TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_escola) REFERENCES Escola(id) ON DELETE CASCADE
);

-- Tabla Incidencia (Reportes de problemas en las aulas)
CREATE TABLE Incidencia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titol VARCHAR(200) NOT NULL,
    descripcio TEXT NOT NULL,
    prioritat ENUM('Alta', 'Mitja', 'Baixa') NOT NULL,
    estat ENUM('Solucionat', 'Pendent') NOT NULL DEFAULT 'Pendent',
    data_incidencia DATE NOT NULL,
    id_aula INT NOT NULL,
    id_usuari INT,
    FOREIGN KEY (id_aula) REFERENCES Aula(id) ON DELETE CASCADE,
    FOREIGN KEY (id_usuari) REFERENCES Usuari(id) ON DELETE SET NULL
);

-- Insertar Escuelas
INSERT INTO Escola (nom, direccio, data_creacio) VALUES
('Escola Primaria Barcelona', 'Carrer de la Pau, 123, Barcelona', '2023-01-01'),
('Escola Secundaria Madrid', 'Avenida Gran Via, 45, Madrid', '2023-02-01'),
('Escola Infantil Valencia', 'Carrer de la Llibertat, 67, Valencia', '2023-03-01'),
('Escola Bressol Sevilla', 'Carrer de la Esperanza, 89, Sevilla', '2023-04-01'),
('Escola Secundaria Bilbao', 'Carrer de la Libertad, 12, Bilbao', '2023-05-01'),
('Escola Primaria Zaragoza', 'Carrer de la Paz, 34, Zaragoza', '2023-06-01'),
('Escola Infantil Málaga', 'Carrer de la Alegría, 56, Málaga', '2023-07-01'),
('Escola Bressol Granada', 'Carrer de la Esperanza, 78, Granada', '2023-08-01'),
('Escola Secundaria Murcia', 'Carrer de la Libertad, 90, Murcia', '2023-09-01'),
('Escola Primaria Palma', 'Carrer de la Pau, 11, Palma', '2023-10-01');

-- Insertar Aulas con periféricos
INSERT INTO Aula (nom, id_escola, num_sillas, num_mesas, num_teclados, num_ratones, num_monitores, num_ordenadores) VALUES
('Aula 101', 1, 20, 10, 5, 5, 3, 2),
('Aula 102', 1, 25, 15, 7, 7, 5, 4),
('Aula 201', 2, 15, 10, 10, 10, 7, 6),
('Aula 202', 2, 20, 10, 8, 8, 6, 5),
('Aula 301', 3, 30, 20, 12, 12, 8, 7),
('Aula 302', 3, 18, 9, 6, 6, 4, 3),
('Aula 401', 4, 22, 11, 9, 9, 5, 4),
('Aula 402', 4, 28, 14, 11, 11, 7, 6),
('Aula 501', 5, 16, 8, 5, 5, 3, 2),
('Aula 502', 5, 24, 12, 10, 10, 6, 5);


-- Insertar Usuarios
INSERT INTO Usuari (nom, tipus, email, contrasenya, assignatura, id_escola, data_registre) VALUES
('Carlos López', 'Professor', 'carlos.lopez@escola.com', 'password123', 'Matemáticas', 1, '2023-01-15'),
('Marta Sánchez', 'Admin Escola', 'marta.sanchez@escola.com', 'adminpass', NULL, 1, '2023-01-20'),
('Javier Pérez', 'Professor', 'javier.perez@escola.com', 'securepass', 'Historia', 2, '2023-02-10'),
('Ana Gómez', 'Admin App', 'ana.gomez@admin.com', 'superadmin', NULL, 2, '2023-02-15'),
('Lucía Fernández', 'Professor', 'lucia.fernandez@escola.com', 'teachpass', 'Ciencias', 3, '2023-03-05'),
('Pedro Martínez', 'Admin Escola', 'pedro.martinez@escola.com', 'adminsecure', NULL, 3, '2023-03-10'),
('Sofía Torres', 'Professor', 'sofia.torres@escola.com', 'mypassword', 'Inglés', 4, '2023-04-01'),
('Raúl García', 'Admin Escola', 'raul.garcia@escola.com', 'admin123', NULL, 4, '2023-04-05');



-- Insertar Incidencias
INSERT INTO Incidencia (titol, descripcio, prioritat, estat, data_incidencia, id_aula, id_usuari) VALUES
('Pizarra rota', 'La pizarra del aula 101 está dañada.', 'Alta', 'Pendent', '2023-10-01', 1, 1),
('Falta de sillas', 'No hay suficientes sillas en el aula 102.', 'Mitja', 'Solucionat', '2023-10-02', 2, 2),
('Teclado no funciona', 'Uno de los teclados del aula 201 está averiado.', 'Alta', 'Pendent', '2023-10-03', 3, 3),
('Ratón defectuoso', 'El ratón del aula 202 no responde correctamente.', 'Baixa', 'Pendent', '2023-10-04', 4, 4),
('Monitor con pantalla rota', 'Un monitor del aula 101 tiene la pantalla dañada.', 'Alta', 'Pendent', '2023-10-05', 1, 1),
('Ordenador no enciende', 'Uno de los ordenadores del aula 201 no enciende.', 'Alta', 'Pendent', '2023-10-06', 3, 3),
('Problema de conexión a internet', 'El aula 301 tiene problemas de conexión a internet.', 'Mitja', 'Pendent', '2023-10-07', 5, 5),
('Fuga de agua en el aula 401', 'Hay una fuga de agua en el aula 401.', 'Alta', 'Pendent', '2023-10-08', 6, 6),
('Falta de material didáctico', 'No hay suficiente material didáctico en el aula 501.', 'Baixa', 'Pendent', '2023-10-09', 7, 7),
('Problema con el proyector', 'El proyector del aula 502 no funciona.', 'Mitja', 'Pendent', '2023-10-10', 8, 8);