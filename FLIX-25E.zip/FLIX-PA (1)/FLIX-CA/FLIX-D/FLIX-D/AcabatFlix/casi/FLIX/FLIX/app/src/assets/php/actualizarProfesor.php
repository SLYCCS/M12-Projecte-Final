<?php

header("Content-Type: application/json");
require_once 'db.php'; // Conexión a la base de datos

$data = json_decode(file_get_contents('php://input'), true);
if (isset($data['nombre'], $data['email'], $data['contrasenya'])) {
    $nombre = $data['nombre'];
    $email = $data['email'];
    $contrasenya = $data['contrasenya'];

    $sql = "UPDATE usuari SET nom = :nombre, contrasenya = :contrasenya WHERE email = :email";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':nombre', $nombre);
    $stmt->bindParam(':contrasenya', $contrasenya);
    $stmt->bindParam(':email', $email);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Profesor actualizado correctamente"]);
    } else {
        echo json_encode(["success" => false, "error" => "Error al actualizar el profesor"]);
    }
} else {
    echo json_encode(["success" => false, "error" => "Datos incompletos"]);
}

?>
