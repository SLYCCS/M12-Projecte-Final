<?php

header("Content-Type: application/json");
require_once 'db.php'; // Conexión a la base de datos

// Verifica si la conexión fue exitosa
if (!$pdo) {
    echo json_encode(['error' => 'Error al conectar con la base de datos.']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);

// Validar si se ha recibido 'id_escola'
if (isset($data['id_escola'])) {
    $idescola = $data['id_escola'];

    $response = [];

    try {
        // Obtener profesores y sus datos
        $query = $pdo->prepare("SELECT * FROM usuari WHERE id_escola = :idescola and tipus = 'professor'");
        $query->bindParam(':idescola', $idescola, PDO::PARAM_INT);
        $query->execute();
        $response['profesores'] = $query->fetchAll(PDO::FETCH_ASSOC);

        // Obtener clases y sus datos
        $query = $pdo->prepare("SELECT * FROM aula WHERE id_escola = :idescola");
        $query->bindParam(':idescola', $idescola, PDO::PARAM_INT);
        $query->execute();
        $response['clases'] = $query->fetchAll(PDO::FETCH_ASSOC);

        // Obtener incidencias con el nombre de la escuela
        $query = $pdo->prepare("
            SELECT incidencia.*, escola.nom AS nom_escola 
            FROM incidencia 
            JOIN aula ON incidencia.id_aula = aula.id 
            JOIN escola ON aula.id_escola = escola.id 
            WHERE escola.id = :idescola
        ");
        $query->bindParam(':idescola', $idescola, PDO::PARAM_INT);
        $query->execute();
        $response['incidencias'] = $query->fetchAll(PDO::FETCH_ASSOC);

        // Devolver la respuesta en formato JSON
        echo json_encode($response);
    } catch (PDOException $e) {
        echo json_encode(['error' => 'Error en la consulta a la base de datos: ' . $e->getMessage()]);
    }
} else {
    // Si no se recibe el id_escola, devolver un error
    echo json_encode(['error' => 'No id_escola provided']);
}

?>
