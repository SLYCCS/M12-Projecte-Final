<?php
include 'db.php';
header("Content-Type: application/json");
$data = json_decode(file_get_contents('php://input'), true);

$id = $data['id'];
$nombre = $data['nombre'];
$num_mesas = $data['num_mesas'];
$num_sillas = $data['num_sillas'];
$num_teclados = $data['num_teclados'];
$num_monitores = $data['num_monitores'];
$num_ordenadores = $data['num_ordenadores'];
$num_ratones = $data['num_ratones'];
$escuela = $data['escuela'];

try {
    $sql = "UPDATE aula SET nom = :nombre, num_mesas = :num_mesas, num_sillas = :num_sillas, num_teclados = :num_teclados, num_monitores = :num_monitores, num_ordenadores = :num_ordenadores, num_ratones = :num_ratones, id_escola = :escuela WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->bindParam(':nombre', $nombre);
    $stmt->bindParam(':num_mesas', $num_mesas);
    $stmt->bindParam(':num_sillas', $num_sillas);
    $stmt->bindParam(':num_teclados', $num_teclados);
    $stmt->bindParam(':num_monitores', $num_monitores);
    $stmt->bindParam(':num_ordenadores', $num_ordenadores);
    $stmt->bindParam(':num_ratones', $num_ratones);
    $stmt->bindParam(':escuela', $escuela);
    $stmt->execute();

    echo json_encode(['success' => true,'Clase actualizada correctamente']);
} catch (PDOException $e) {
    echo json_encode(['success' => false ,$e->getMessage()]);
}
?>