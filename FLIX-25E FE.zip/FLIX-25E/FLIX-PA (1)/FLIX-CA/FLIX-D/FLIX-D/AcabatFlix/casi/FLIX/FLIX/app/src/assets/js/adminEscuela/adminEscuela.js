let escuela;
let clases;
let profesores;
let incidencias;
// Recuperar los datos cifrados desde localStorage
const textoCifradoRecuperado = localStorage.getItem('datosCifrados');
document.getElementById('btnCerrarSesion').addEventListener('click', function() {
    // Eliminar usuario y escuela del localStorage
    localStorage.removeItem('datosCifrados');
    
    // Redirigir a la página de login
    window.location.href = "../login.html";
});
if (textoCifradoRecuperado) {
    const claveCesar = 3; // Usar la misma clave para el descifrado

    // Descifrar los datos
    const textoDescifrado = descifrarCesar(textoCifradoRecuperado, claveCesar);

    // Convertir el texto descifrado de vuelta al objeto
    const dataDescifrada = JSON.parse(textoDescifrado);
    const nombreUsuarioBienvenida = document.getElementById('nombreUsuarioBienvenida');
        if (nombreUsuarioBienvenida) {
            nombreUsuarioBienvenida.textContent = dataDescifrada.nombre;
        } else {
            console.error('Elemento con ID "nombreProfesor" no encontrado.');
        }
    escuela = dataDescifrada;
    
    console.log('Datos descifrados:', dataDescifrada);
    if (dataDescifrada.rol === "Admin Escola") {
        console.log('Rol correcto');
        cargarDatosAdminEscuela();
    } else if (dataDescifrada.rol === "Professor") {
        window.location.href = "../profesor/profesorInicio.html";
    } else if (dataDescifrada.rol === "Admin App") {
        window.location.href = "../adminAplicacion/adminAplicacionInicio.html";
    }
} else {
    window.location.href = "../login.html"; // Redirigir al login si no hay datos cifrados
}
function cifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) { // Solo ciframos las letras
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65; // Para minúsculas (97) y mayúsculas (65)
            return String.fromCharCode(((code - base + clave) % 26) + base);
        }
        return char; // No ciframos otros caracteres
    }).join('');
}

// Función para descifrar un texto usando un desplazamiento (clave)
function descifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) {
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65;
            return String.fromCharCode(((code - base - clave + 26) % 26) + base); // Restamos la clave para descifrar
        }
        return char; // No desciframos otros caracteres
    }).join('');
}


// Evento para cerrar sesión
document.getElementById('btnCerrarSesion').addEventListener('click', function() {
    // Eliminar usuario y escuela del localStorage
    localStorage.removeItem('datosCifrados');
    
    // Redirigir a la página de login
    window.location.href = "../login.html";
});
// Función para rellenar los selects de las clases de las incidencias
function llenarSelectClases(clases) {
    const selectClases = document.getElementById('selectClase');
    selectClases.innerHTML = ""; // Limpiar cualquier contenido previo
  
    
    clases.forEach(clase => {
        const option = document.createElement('option');
        option.value = clase.id; // Usar el id de la clase como valor
        option.textContent = clase.nom; // Usar el nombre de la clase como texto
        selectClases.appendChild(option);
    });
}

// Cargar los datos de la escuela para el administrador
function cargarDatosAdminEscuela() {
    console.log(escuela);
    
    fetch('../../assets/php/adminescola.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id_escola: escuela.id_escola })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Respuesta del servidor no válida.");
        }
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
            return response.json(); // Parseamos la respuesta a JSON
        } else {
            throw new Error("Respuesta del servidor no es JSON.");
        }
    })
    .then(data => {
        console.log('Respuesta del servidor:', data);
        
        if (!data || !data.clases) {
            throw new Error("La respuesta del servidor es inválida.");
        }

        clases = data.clases;
        profesores = data.profesores;
        incidencias = data.incidencias;


        
        llenarSelectClases(clases);

        const listaProfesores = document.getElementById('listaProfesores');
        listaProfesores.innerHTML = "";
        profesores.forEach(usuario => {
            if (usuario.tipus === "Professor") {
                const divProfesor = document.createElement('div');
                divProfesor.classList.add('col-md-4', 'mb-3');
                divProfesor.innerHTML = `
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">${usuario.nom}</h5>
                            <p class="card-text">Email: ${usuario.email}</p>
                            <button class="btn btn-secondary" onclick="editarProfesor('${usuario.email}')">Editar</button>
                            <button class="btn btn-danger" onclick="eliminarProfesor('${usuario.email}')">Eliminar</button>
                        </div>
                    </div>
                `;
                listaProfesores.appendChild(divProfesor);
            }
        });

        const listaClases = document.getElementById('listaClases');
        listaClases.innerHTML = "";
        
        clases.forEach((clase) => {
            const divClase = document.createElement('div');
            divClase.classList.add('col-md-4', 'mb-3');
            divClase.innerHTML = `
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">${clase.nom}</h5>
                        <p class="card-text">Mesas: ${clase.num_mesas}</p>
                        <p class="card-text">Sillas: ${clase.num_sillas}</p>
                        <p class="card-text">Teclados: ${clase.num_teclados}</p>
                        <p class="card-text">Ratones: ${clase.num_ratones}</p>
                        <p class="card-text">Pantallas: ${clase.num_monitores}</p>
                        <p class="card-text">Ordenadores: ${clase.num_ordenadores}</p>
                        <button class="btn btn-secondary" onclick="editarClase(${clase.id})">Editar</button>
                        <button class="btn btn-danger" onclick="eliminarClase(${clase.id})">Eliminar</button>
                    </div>
                </div>
            `;
            listaClases.appendChild(divClase);
        });

        const listaIncidencias = document.getElementById('listaIncidencias');
        listaIncidencias.innerHTML = "";
        
        incidencias.forEach((incidencia) => {
            
            incidencia.clase = clases.find(clase => clase.id === incidencia.id_aula).nom;
            
            const divIncidencia = document.createElement('div');
            divIncidencia.classList.add('col-md-4', 'mb-3');
            divIncidencia.innerHTML = `
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title" id="idIncidencia">Incidencia ${incidencia.id}</h5>
                        <p class="card-text">Título: ${incidencia.titol}</p>
                        <p class="card-text" id = ${incidencia.id_aula}>Clase: ${incidencia.clase}</p>
                        <p class="card-text">Descripción: ${incidencia.descripcio}</p>
                        <p class="card-text">Fecha: ${incidencia.data_incidencia}</p>
                        <p class="card-text">Relevancia: ${incidencia.prioritat}</p>
                        <p class="card-text">Estado: ${incidencia.estat}</p>
                        <button class="btn btn-secondary" onclick="editarIncidencia(${incidencia.id})">Editar</button>
                        <button class="btn btn-danger" onclick="eliminarIncidencia(${incidencia.id})">Eliminar</button>
                    </div>
                </div>
            `;
            listaIncidencias.appendChild(divIncidencia);
        });
    })
    .catch(error => {
        console.error('Error al cargar los datos:', error);
    });
}



function editarProfesor(email) {
    // Obtener el profesor por email (suponiendo que esta función existe)
    const profesor = profesores.find(profesor => profesor.email === email);
    
    if (profesor) {
        // Asignar los valores de los campos del formulario
        document.getElementById('nombreProfesor').value = profesor.nom;
        document.getElementById('emailProfesor').value = profesor.email;
        document.getElementById('contraseñaProfesor').value = profesor.contrasenya || ''; // Aseguramos que cargue la contraseña

        // Cambiar el modo de edición (puedes usarlo para lógica en el servidor o el formulario)
        document.getElementById('modoEdicionProfesor').value = 'editar';
        document.getElementById('emailProfesor').disabled = true;
        // Establecer el evento para guardar el profesor, asegurando que no se sobrescriba el evento
        const btnGuardar = document.getElementById('btnGuardarProfesor');
        btnGuardar.onclick = function() {
            guardarProfesor(profesor.email); // Asumiendo que 'guardarProfesor' usa el email
        };

        // Mostrar el modal usando Bootstrap 5
        const modalProfesor = new bootstrap.Modal(document.getElementById('modalProfesor'));
        modalProfesor.show();
    }
}


// Función para crear un nuevo profesor
function crearProfesor() {
    document.getElementById('emailProfesor').disabled = false;
    document.getElementById('nombreProfesor').value = '';
    document.getElementById('emailProfesor').value = '';
    document.getElementById('contraseñaProfesor').value = ''; // Limpiar la contraseña
    document.getElementById('btnGuardarProfesor').onclick = () => guardarProfesor(null);
    document.getElementById('modoEdicionProfesor').value = 'crear'; // Modo creación
    $('#modalProfesor').modal('show');
}

// Función para guardar un profesor
function guardarProfesor(email) {
    const nombre = document.getElementById('nombreProfesor').value;
    const emailProfesor = document.getElementById('emailProfesor').value;
    const contraseñaProfesor = document.getElementById('contraseñaProfesor').value;
    const modoEdicion = document.getElementById('modoEdicionProfesor').value;
    
    // Validar el correo electrónico
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailProfesor)) {
        alert("Por favor, introduce un correo electrónico válido.");
        return;
    }
    // Validar los campos del formulario
    if (!nombre || !emailProfesor || !contraseñaProfesor) {
        alert("Por favor, completa todos los campos.");
        return;
    }
    if (modoEdicion === 'editar' && email) {

        // Realizar la petición para actualizar el profesor
        fetch('../../assets/php/actualizarProfesor.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nombre, email: emailProfesor, contrasenya: contraseñaProfesor, escuela: escuela.id_escola })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error("Error al actualizar el profesor en la base de datos.");
            }
            return response.json();
        })
        .then(data => {
            
            if (data.success) {
                cargarDatosAdminEscuela();
                console.log("Profesor actualizado correctamente.");
            } else {
                throw new Error("Error en la respuesta del servidor al actualizar el profesor.");
            }
        })
        .catch(error => {
            console.error("Error al actualizar el profesor:", error);
        });
        // Cargar datos nuevamente y ocultar el modal
    cargarDatosAdminEscuela();
    $('#modalProfesor').modal('hide'); // Ocultamos el modal

    } else if (modoEdicion === 'crear') {

        // Realizar la petición para crear el profesor
        fetch('../../assets/php/crearProfesor.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nombre, email: emailProfesor, contrasenya: contraseñaProfesor, escuela: escuela.id_escola })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error("Error al crear el profesor en la base de datos.");
            }
            return response.json();
        })
        .then(data => {
            
            if (data.success) {
                cargarDatosAdminEscuela();
                console.log("Profesor creado correctamente.");
            } else {
                throw new Error("Error en la respuesta del servidor al crear el profesor.");
            }
        })
        .catch(error => {
            console.error("Error al crear el profesor:", error);
        });
        // Cargar datos nuevamente y ocultar el modal
    cargarDatosAdminEscuela();
    $('#modalProfesor').modal('hide'); // Ocultamos el modal
    }

    cargarDatosAdminEscuela();
    $('#modalProfesor').modal('hide'); // Ocultamos el modal
    

}


// Función para eliminar un profesor
function eliminarProfesor(email) {
    const modalConfirmacion = new bootstrap.Modal(document.getElementById('modalPregunta'));
    modalConfirmacion.show();
    document.getElementById('btnConfirmarIncidencia').onclick = function() {
        fetch('../../assets/php/eliminarProfesor.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: email, escuela: escuela.id_escola })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error("Error al eliminar el profesor en la base de datos.");
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                console.log("Profesor eliminado correctamente.");
                cargarDatosAdminEscuela();
            } else {
                throw new Error("Error en la respuesta del servidor al eliminar el profesor.");
            }
        })
        .catch(error => {
            console.error("Error al eliminar el profesor:", error);
        });
        modalConfirmacion.hide();
    };
    
    cargarDatosAdminEscuela();
}

// Función para editar una clase
function editarClase(id) {
        const clase = clases.find(clase => clase.id === id);
        // Mostrar el nombre de la clase en el modal
        document.getElementById('nombreClase').value = clase.nom;
        // Mostrar los ítems de la clase en el modal
        document.getElementById('mesasClase').value = clase.num_mesas;
        document.getElementById('sillasClase').value = clase.num_sillas;
        document.getElementById('tecladosClase').value = clase.num_teclados;
        document.getElementById('pantallasClase').value = clase.num_monitores;
        document.getElementById('ordenadoresClase').value = clase.num_ordenadores;
        document.getElementById('ratonesClase').value = clase.num_ratones;

        // Asignar el evento al botón de guardar 
        document.getElementById('btnGuardarClase').onclick = () => guardarClase(clase.id);
    document.getElementById('modoEdicionClase').value = 'editar'; // Modo edición
    $('#modalClase').modal('show');
}

// Función para crear una nueva clase
function crearClase() {
    document.getElementById('nombreClase').value = '';
    document.getElementById('mesasClase').value = '';
    document.getElementById('sillasClase').value = '';
    document.getElementById('tecladosClase').value = '';
    document.getElementById('pantallasClase').value = '';
    document.getElementById('ordenadoresClase').value = '';
    document.getElementById('ratonesClase').value = '';
    document.getElementById('btnGuardarClase').onclick = () => guardarClase(null);
    document.getElementById('modoEdicionClase').value = 'crear'; // Modo creación
    $('#modalClase').modal('show');
}

// Función para eliminar una clase
function eliminarClase(index) {
    const modalConfirmacion = new bootstrap.Modal(document.getElementById('modalPregunta'));
    modalConfirmacion.show();
    document.getElementById('btnConfirmarIncidencia').onclick = function() {
        fetch('../../assets/php/eliminarClase.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: index, escuela: escuela.id_escola })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error("Error al eliminar la clase en la base de datos.");
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                console.log("Clase eliminada correctamente.");
                cargarDatosAdminEscuela();
            } else {
                throw new Error("Error en la respuesta del servidor al eliminar la clase.");
            }
        })
        .catch(error => {
            console.error("Error al eliminar la clase:", error);
        });
        modalConfirmacion.hide();
    };
    cargarDatosAdminEscuela();
}

// Función para guardar una clase
function guardarClase(index) {
const nombre = document.getElementById('nombreClase').value;
const num_mesas = document.getElementById('mesasClase').value;
const num_sillas = document.getElementById('sillasClase').value;
const num_teclados = document.getElementById('tecladosClase').value;
const num_monitores = document.getElementById('pantallasClase').value;
const num_ordenadores = document.getElementById('ordenadoresClase').value;
const num_ratones = document.getElementById('ratonesClase').value;
const modoEdicion = document.getElementById('modoEdicionClase').value;

if (modoEdicion === 'editar' && index !== null) {
    fetch('../../assets/php/actualizarClase.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: index, nombre, num_mesas, num_sillas, num_teclados, num_monitores, num_ordenadores, num_ratones, escuela: escuela.id_escola })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Error al actualizar la clase en la base de datos.");
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            cargarDatosAdminEscuela();
            console.log("Clase actualizada correctamente.");
        } else {
            throw new Error("Error en la respuesta del servidor al actualizar la clase.");
        }
    })
    .catch(error => {
        console.error("Error al actualizar la clase:", error);
    });
} else if (modoEdicion === 'crear') {
    fetch('../../assets/php/crearClase.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nombre, num_mesas, num_sillas, num_teclados, num_monitores, num_ordenadores, num_ratones, escuela: escuela.id_escola })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Error al crear la clase en la base de datos.");
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            cargarDatosAdminEscuela();
            console.log("Clase creada correctamente.");
        } else {
            throw new Error("Error en la respuesta del servidor al crear la clase.");
        }
    })
    .catch(error => {
        console.error("Error al crear la clase:", error);
    });
}
    cargarDatosAdminEscuela();
    $('#modalClase').modal('hide'); // Ocultar modal
}
// Función para editar una incidencia
function editarIncidencia(index) {
    const incidencia = incidencias.find(incidencia => incidencia.id === index);
    incidencia.clase = clases.find(clase => clase.id === incidencia.id_aula).nom;
    console.log(incidencia.titol);
    document.getElementById('tituloIncidencia').value = incidencia.titol;
    document.getElementById('descripcionIncidencia').value = incidencia.descripcio;
    document.getElementById('selectClase').value = incidencia.id_aula;
    document.getElementById('selectTipoIncidencia').value = incidencia.prioritat;
    document.getElementById('estadoIncidencia').value = incidencia.estat;
    document.getElementById('btnGuardarIncidencia').onclick = () => guardarIncidencia(index);
    document.getElementById('modoEdicionIncidencia').value = 'editar'; // Modo edición
    $('#modalIncidencia').modal('show');
}

// Función para crear una nueva incidenciaSSSSS
function crearIncidencia() {
    document.getElementById('descripcionIncidencia').value = '';
    document.getElementById('tituloIncidencia').value = '';
    document.getElementById('selectClase').value = '';
    document.getElementById('selectTipoIncidencia').value = '';
    document.getElementById('estadoIncidencia').value = '';
    document.getElementById('btnGuardarIncidencia').onclick = () => guardarIncidencia(null);
    document.getElementById('modoEdicionIncidencia').value = 'crear'; // Modo creación
    $('#modalIncidencia').modal('show');
}

// Función para guardar una incidencia
function guardarIncidencia(index) {
    const descripcion = document.getElementById('descripcionIncidencia').value;
    const tituloClaseIncidencia = document.getElementById('tituloIncidencia').value;
    const claseSeleccionada = document.getElementById('selectClase').value;
    let nombreClaseIncidencia = claseSeleccionada;
    const estado = document.getElementById('estadoIncidencia').value;
    const relevanciaSeleccionada = document.getElementById('selectTipoIncidencia').value;
    const usuarioAsignado = escuela.id; // Asignar el usuario actual
    const modoEdicion = document.getElementById('modoEdicionIncidencia').value;
    console.log(tituloClaseIncidencia);
    
    // Crear nueva incidencia
    const incidencia = {
        titol: tituloClaseIncidencia,
        id_aula: nombreClaseIncidencia,
        descripcio: descripcion,
        data_incidencia: new Date().toISOString().split('T')[0], // Fecha actual en formato YYYY-MM-DD
        estat: estado,
        prioritat: relevanciaSeleccionada,
        id_professor: usuarioAsignado
    };
    // Validar que todos los campos estén llenos
    if (!tituloClaseIncidencia || !descripcion || !claseSeleccionada || !estado || !relevanciaSeleccionada) {
        alert("Por favor, completa todos los campos.");
        return;
    }
    if (modoEdicion === 'editar' && index !== null) {
        incidencia.id = index;
        fetch('../../assets/php/actualizarIncidencia.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(incidencia)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error("Error al actualizar la incidencia en la base de datos.");
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                cargarDatosAdminEscuela();
                console.log("Incidencia actualizada correctamente.");
            } else {
                throw new Error("Error en la respuesta del servidor al actualizar la incidencia.");
            }
        })
        .catch(error => {
            console.error("Error al actualizar la incidencia:", error);
        });
    } else if (modoEdicion === 'crear') {
        fetch('../../assets/php/crearIncidencia.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(incidencia)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error("Error al crear la incidencia en la base de datos.");
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                cargarDatosAdminEscuela();
                console.log("Incidencia creada correctamente.");
            } else {
                throw new Error("Error en la respuesta del servidor al crear la incidencia.");
            }
        })
        .catch(error => {
            console.error("Error al crear la incidencia:", error);
        });
    }

    cargarDatosAdminEscuela();
    $('#modalIncidencia').modal('hide'); // Ocultar modal
}

// Función para eliminar una incidencia
function eliminarIncidencia(index) {
    const modalConfirmacion = new bootstrap.Modal(document.getElementById('modalPregunta'));
    modalConfirmacion.show();
    document.getElementById('btnConfirmarIncidencia').onclick = function() {
        const incidencia = incidencias.find(incidencia => incidencia.id === index);
        fetch('../../assets/php/eliminarIncidencia.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: index, escuela: incidencia.id_aula })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error("Error al eliminar la incidencia en la base de datos.");
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                console.log("Incidencia eliminada correctamente.");
                cargarDatosAdminEscuela();
            } else {
                throw new Error("Error en la respuesta del servidor al eliminar la incidencia.");
            }
        })
        .catch(error => {
            console.error("Error al eliminar la incidencia:", error);
        });
        modalConfirmacion.hide();
    };
}