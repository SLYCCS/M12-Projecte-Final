<?php
header("Content-Type: application/json");
require_once 'db.php'; // Conexión a la base de datos

$sql = "SELECT * FROM escuelas";
  $stmt = $pdo->prepare("SELECT id, nom, tipus, id_escola FROM usuari WHERE email = ? AND contrasenya = ?");
    $stmt->execute([$email, $password]); // Aquí se pasa el email y la contraseña directamente

echo json_encode($escuelas);




?>