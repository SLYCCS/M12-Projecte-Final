<?php
require_once 'db.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
if (isset($data['titol'], $data['id_aula'], $data['descripcio'], $data['data_incidencia'], $data['estat'], $data['prioritat'], $data['id_professor'])) {
    $titol = $data['titol'];
    $id_aula = $data['id_aula'];
    $descripcio = $data['descripcio'];
    $data_incidencia = $data['data_incidencia'];
    $estat = $data['estat'];
    $prioritat = $data['prioritat'];
    $id_professor = $data['id_professor'];
    try {
        $sql = "INSERT INTO incidencia (titol, id_aula, descripcio, data_incidencia, estat, prioritat, id_usuari) 
                VALUES (:titol, :id_aula, :descripcio, :data_incidencia, :estat, :prioritat, :id_professor)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':titol', $titol);
        $stmt->bindParam(':id_aula', $id_aula);
        $stmt->bindParam(':descripcio', $descripcio);
        $stmt->bindParam(':data_incidencia', $data_incidencia);
        $stmt->bindParam(':estat', $estat);
        $stmt->bindParam(':prioritat', $prioritat);
        $stmt->bindParam(':id_professor', $id_professor);

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Incidencia creada exitosamente']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error al crear la incidencia']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error de base de datos: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
}
?>