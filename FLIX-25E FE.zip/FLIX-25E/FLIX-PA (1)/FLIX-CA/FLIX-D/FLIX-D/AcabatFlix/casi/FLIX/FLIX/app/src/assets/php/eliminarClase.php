<?php
// Include the database connection file
require_once 'db.php';

// Get the JSON input
$data = json_decode(file_get_contents('php://input'), true);

// Check if the required data is present
if (isset($data['id']) && isset($data['escuela'])) {
    $idClase = $data['id'];
    $idEscuela = $data['escuela'];

    try {
        // Prepare the SQL statement
        $stmt = $pdo->prepare('DELETE FROM aula WHERE id = :idClase AND id_escola = :idEscuela');
        
        // Bind the parameters
        $stmt->bindParam(':idClase', $idClase, PDO::PARAM_INT);
        $stmt->bindParam(':idEscuela', $idEscuela, PDO::PARAM_INT);
        
        // Execute the statement
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Class deleted successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to delete class']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
}
?>