<?php

header("Content-Type: application/json");
require_once 'db.php'; // Conexión a la base de datos

$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['nombre'], $data['email'], $data['contrasenya'], $data['escuela'])) {
    $nombre = $data['nombre'];
    $email = $data['email'];
    $contrasenya = $data['contrasenya'];
    $escola = $data['escuela'];

    $sql = "INSERT INTO usuari (nom, tipus, email, contrasenya, id_escola) VALUES (?, 'Professor', ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$nombre, $email, $contrasenya, $escola]);

    if ($stmt->rowCount() === 1) {
        echo json_encode(["success" => true, "message" => "Profesor creado correctamente"]);
    } else {
        echo json_encode(["success" => false, "error" => "Error al crear el profesor"]);
    }
} else {
    echo json_encode(["success" => false, "error" => "Datos incompletos"]);
}

?>
