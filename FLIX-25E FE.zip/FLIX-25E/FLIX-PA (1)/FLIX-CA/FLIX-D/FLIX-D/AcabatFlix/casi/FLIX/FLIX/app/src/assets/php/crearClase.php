<?php
require_once 'db.php';

$data = json_decode(file_get_contents('php://input'), true);

$nombre = $data['nombre'];
$num_mesas = $data['num_mesas'];
$num_sillas = $data['num_sillas'];
$num_teclados = $data['num_teclados'];
$num_monitores = $data['num_monitores'];
$num_ordenadores = $data['num_ordenadores'];
$num_ratones = $data['num_ratones'];
$escuela = $data['escuela'];

try {
    $sql = "INSERT INTO aula (nom, num_mesas, num_sillas, num_teclados, num_monitores, num_ordenadores, num_ratones, id_escola) 
            VALUES (:nombre, :num_mesas, :num_sillas, :num_teclados, :num_monitores, :num_ordenadores, :num_ratones, :escuela)";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':nombre', $nombre);
    $stmt->bindParam(':num_mesas', $num_mesas);
    $stmt->bindParam(':num_sillas', $num_sillas);
    $stmt->bindParam(':num_teclados', $num_teclados);
    $stmt->bindParam(':num_monitores', $num_monitores);
    $stmt->bindParam(':num_ordenadores', $num_ordenadores);
    $stmt->bindParam(':num_ratones', $num_ratones);
    $stmt->bindParam(':escuela', $escuela);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Clase creada exitosamente']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al crear la clase']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Error de conexión: ' . $e->getMessage()]);
}
?>