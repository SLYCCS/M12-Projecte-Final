// Función para cifrar un texto usando un desplazamiento (clave)
function cifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) { // Solo ciframos las letras
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65; // Para minúsculas (97) y mayúsculas (65)
            return String.fromCharCode(((code - base + clave) % 26) + base);
        }
        return char; // No ciframos otros caracteres
    }).join('');
}

// Función para descifrar un texto usando un desplazamiento (clave)
function descifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) {
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65;
            return String.fromCharCode(((code - base - clave + 26) % 26) + base); // Restamos la clave para descifrar
        }
        return char; // No desciframos otros caracteres
    }).join('');
}
// Evento para cerrar sesión
document.getElementById('btnCerrarSesion').addEventListener('click', function() {
    // Eliminar usuario y escuela del localStorage
    localStorage.removeItem('datosCifrados');
    
    // Redirigir a la página de login
    window.location.href = "../login.html";
});
// Recuperar los datos cifrados desde localStorage
const textoCifradoRecuperado = localStorage.getItem('datosCifrados');
if (textoCifradoRecuperado) {
    const claveCesar = 3; // Usar la misma clave para el descifrado

    // Descifrar los datos
    const textoDescifrado = descifrarCesar(textoCifradoRecuperado, claveCesar);

    // Convertir el texto descifrado de vuelta al objeto
    const dataDescifrada = JSON.parse(textoDescifrado);

    console.log('Datos descifrados:', dataDescifrada);
    if (dataDescifrada.rol === "Admin App") {
        console.log('Rol correcto');
    } else if (dataDescifrada.rol === "Professor") {
        window.location.href = "../profesor/profesorInicio.html";
    } else if (dataDescifrada.rol === "Admin Escola") {
        window.location.href = "../adminEscuela/adminEscuelaInicio.html";
    }
    document.getElementById('nombreUsuarioBienvenida').innerText = dataDescifrada.nombre;
} else {
    window.location.href = "../login.html"; // Redirigir al login si no hay datos cifrados
}



// Función para cargar las escuelas desde la base de datos
async function cargarDatosEscuelas() {
    try {
        const response = await fetch('../../assets/php/escuelasAdmin.php');
        if (!response.ok) {
            throw new Error('Error al cargar las escuelas');
        }
        return await response.json();
    } catch (error) {
        console.error(error);
        return [];
    }
}
// Función para mostrar el listado de escuelas en formato de tarjetas
async function mostrarEscuelasTarjetas() {
    const escuelas = await cargarDatosEscuelas();
    const listaEscuelas = document.getElementById('listadoEscuelas');
    listaEscuelas.innerHTML = ''; // Limpiar el contenido previo
    escuelas.forEach((escuela) => {
        console.log(escuela);

        const divEscuela = document.createElement('div');
        divEscuela.classList.add('col-md-4', 'mb-3');
        divEscuela.innerHTML = `
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">${escuela.nom}</h5>
                    <p class="card-text">${escuela.direccio}</p>
                    <button class="btn btn-secondary" onclick="editarEscuela(${escuela.id})">Editar</button>
                    <button class="btn btn-danger" onclick="eliminarEscuela(${escuela.id})">Eliminar</button>
                </div>
            </div>
        `;
        listaEscuelas.appendChild(divEscuela);
    });
    const usuarios = await cargarDatosUsuarios();
    const listaUsuarios = document.getElementById('listadoUsuarios');
    console.log(usuarios);
    
    listaUsuarios.innerHTML = ''; // Limpiar el contenido previo
    usuarios.forEach((usuario) => {
        console.log(usuario);

        const divUsuario = document.createElement('div');
        divUsuario.classList.add('col-md-4', 'mb-3');
        divUsuario.innerHTML = `
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">${usuario.nom}</h5>
                    <p class="card-text">${usuario.email}</p>
                    <p class="card-text">${usuario.tipus}</p>
                    <p class="card-text">${usuario.escuela}</p>
                </div>
            </div>
        `;
        listaUsuarios.appendChild(divUsuario);

    });


}
async function cargarDatosUsuarios() {
    try {
        const response = await fetch('../../assets/php/usuariosAdmin.php');
        if (!response.ok) {
            throw new Error('Error al cargar los usuarios');
        }
        return await response.json();
    } catch (error) {
        console.error(error);
        return [];
    }
}

mostrarEscuelasTarjetas();
// Función para editar una escuela
async function editarEscuela(id) {
    const escuelas = await cargarDatosEscuelas();
    const escuela = escuelas.find(esc => esc.id === id);
    
    if (escuela) {
        document.getElementById('nombreNuevaEscuela').value = escuela.nom;
        document.getElementById('direccionNuevaEscuela').value = escuela.direccio;
        document.getElementById('modoEdicionEscuela').value = 'editar';
        
        const btnGuardar = document.getElementById('btnGuardarEscuela');
        btnGuardar.onclick = function() {
            if (!document.getElementById('nombreNuevaEscuela').value.trim()) {
                alert("El nombre de la escuela no puede estar vacío.");
                return;
            }
            if (!document.getElementById('direccionNuevaEscuela').value.trim()) {
                alert("La dirección de la escuela no puede estar vacía.");
                return;
            }
            guardarEscuela(escuela.id);
        };

        const modalEscuela = new bootstrap.Modal(document.getElementById('modalCrearEscuela'));
        modalEscuela.show();
    }
}
// Función para mostrar el modal de crear escuela
function mostrarModalCrearEscuela() {
    document.getElementById('nombreNuevaEscuela').value = '';
    document.getElementById('modoEdicionEscuela').value = 'crear';
    document.getElementById('direccionNuevaEscuela').value = '';
    const modalEscuela = new bootstrap.Modal(document.getElementById('modalCrearEscuela'));
    modalEscuela.show();
    const btnGuardar = document.getElementById('btnGuardarEscuela');
    btnGuardar.onclick = () => guardarEscuela(null);
}
// Función para guardar una escuela
async function guardarEscuela(id) {
    console.log('Guardando escuela...');
    
    const nombre = document.getElementById('nombreNuevaEscuela').value;
    const direccion = document.getElementById('direccionNuevaEscuela').value;
    const modoEdicion = document.getElementById('modoEdicionEscuela').value;
    
    if (!nombre) {
        alert("El nombre de la escuela no puede estar vacío.");
        return;
    }

    if (!direccion) {
        alert("La dirección de la escuela no puede estar vacía.");
        return;
    }

    const escuelas = await cargarDatosEscuelas();
    
    if (modoEdicion === 'editar' && id !== null) {
        const escuela = escuelas.find(esc => esc.id === id);
        if (escuela) {
            escuela.nom = nombre;
            escuela.direccio = direccion;
        }
        fetch('../../assets/php/actualizarescuelas.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(escuela)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Escuela actualizada con éxito');
                mostrarEscuelasTarjetas();
            } else {
                console.error('Error al actualizar la escuela');
            }
        })
        .catch(error => console.error(error));
    } else if (modoEdicion === 'crear') {
     
        
        const nuevaEscuela = { nom: nombre, direccio: direccion };
        fetch('../../assets/php/crearescuelas.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(nuevaEscuela)
        })
        .then (response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Escuela creada con éxito');
                mostrarEscuelasTarjetas();
            } else {
                console.error('Error al crear la escuela');
            }
        })
    }

    mostrarEscuelasTarjetas();
    
    const modalEscuela = bootstrap.Modal.getInstance(document.getElementById('modalCrearEscuela'));
    modalEscuela.hide();
}


async function eliminarEscuela(id) {
    const escuelas = await cargarDatosEscuelas();
    const escuela = escuelas.find(esc => esc.id === id);

    if (escuela) {
        // Mostrar modal de confirmación
        const modalPregunta = new bootstrap.Modal(document.getElementById('modalPregunta'));
        document.getElementById('modalPreguntaLabel').innerText = `¿Estás seguro de que deseas eliminar la escuela ${escuela.nom}?`;

        document.getElementById('btnConfirmarIncidencia').onclick = async function() {
            fetch('../../assets/php/eliminarescuelas.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: escuela.id })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log('Escuela eliminada con éxito');
                    mostrarEscuelasTarjetas();
                } else {
                    console.error('Error al eliminar la escuela');
                }
            })
            .catch(error => console.error(error));

            modalPregunta.hide();
        };

        modalPregunta.show();
    }
}



// Mostrar modal para crear nuevo usuario
function mostrarModalCrearUsuario() {
    $('#modalCrearUsuario').modal('show');
    $('#nombreUsuario').val('');
    $('#emailUsuario').val('');
    $('#rolUsuario').val('');
    cargarEscuelasEnSelect();
}


// Cargar escuelas en el select del modal de usuario
async function cargarEscuelasEnSelect() {
    const escuelas = await cargarDatosEscuelas();
    let opciones = '';
    escuelas.forEach((escuela, index) => {
        opciones += `<option value="${index}">${escuela.nom}</option>`;
    });
    $('#escuelaUsuario').html(opciones);
}



// Función para mostrar usuarios de una escuela
async function verUsuarios(escuelaIndex) {
    
}

// Función para guardar nuevo usuario
async function guardarUsuario() {
    const nombreUsuario = $('#nombreUsuario').val();
    const emailUsuario = $('#emailUsuario').val();
    const rolUsuario = $('#rolUsuario').val();
    const escuelaUsuarioIndex = $('#escuelaUsuario').val();
    const escuelas = await cargarDatosEscuelas();

    if (nombreUsuario && emailUsuario && rolUsuario && escuelaUsuarioIndex !== null) {
        const nuevoUsuario = { nombre: nombreUsuario, email: emailUsuario, rol: rolUsuario };
        escuelas[escuelaUsuarioIndex].usuarios.push(nuevoUsuario);
        await guardarDatosEscuelas(escuelas);
        alert('Usuario creado con éxito');
        $('#modalCrearUsuario').modal('hide');
        verUsuarios(escuelaUsuarioIndex); // Mostrar los usuarios de la escuela
    } else {
        alert('Todos los campos son obligatorios');
    }
}