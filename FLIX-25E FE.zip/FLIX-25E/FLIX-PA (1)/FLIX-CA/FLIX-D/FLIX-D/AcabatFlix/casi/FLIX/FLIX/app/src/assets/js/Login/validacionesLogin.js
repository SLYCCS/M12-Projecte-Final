// Función para cifrar un texto usando un desplazamiento (clave)
function cifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) { // Solo ciframos las letras
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65; // Para minúsculas (97) y mayúsculas (65)
            return String.fromCharCode(((code - base + clave) % 26) + base);
        }
        return char; // No ciframos otros caracteres
    }).join('');
}

// Función para descifrar un texto usando un desplazamiento (clave)
function descifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) {
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65;
            return String.fromCharCode(((code - base - clave + 26) % 26) + base); // Restamos la clave para descifrar
        }
        return char; // No desciframos otros caracteres
    }).join('');
}

// Recuperar los datos cifrados desde localStorage
let textoCifradoRecuperado = localStorage.getItem('datosCifrados');
if (textoCifradoRecuperado) {
    textoCifradoRecuperado = descifrarCesar(textoCifradoRecuperado, 3);
    console.log('Datos descifrados:', textoCifradoRecuperado);
}

if (textoCifradoRecuperado) {
    textoCifradoRecuperado = JSON.parse(textoCifradoRecuperado);
    console.log(textoCifradoRecuperado.rol);
    if (textoCifradoRecuperado.rol === "Professor") {
        window.location.href = "../pages/profesor/profesorInicio.html";
    } else if (textoCifradoRecuperado.rol === "Admin Escola") {
        window.location.href = "../pages/adminEscuela/adminEscuelaInicio.html";
    } else if (textoCifradoRecuperado.rol === "Admin App") {
        window.location.href = "../pages/adminAplicacion/adminAplicacionInicio.html";
    }
}
// Obtener elementos del formulario
var loginForm = document.getElementById('form');
var submitButton = document.getElementById('submit');
var inputEmail = document.getElementById('Email1');
var inputPassword = document.getElementById('Password1');
var errorEmail = document.getElementById('errorEmail');
var errorPassword = document.getElementById('errorPassword');
var errorForm = document.getElementById('errorForm');

// Función para validar el correo
function validarEmail() {
    let email = inputEmail.value.trim();
    const emailPattern = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;

    if (!emailPattern.test(email)) {
        inputEmail.classList.add('is-invalid');
        errorEmail.classList.add('text-danger');
        errorEmail.textContent = "Introduzca una dirección de correo válida.";
        return false;
    } else {
        inputEmail.classList.remove('is-invalid');
        inputEmail.classList.add('is-valid');
        errorEmail.classList.remove('text-danger');
        errorEmail.textContent = "";
        return true;
    }
}

// Función para validar la contraseña
function validarPassword() {
    let password = inputPassword.value.trim();
    const passwordPattern = /^[A-Za-z0-9!@#%&*._-]+$/;

    if (!passwordPattern.test(password) || password.length < 8) {
        inputPassword.classList.add('is-invalid');
        errorPassword.classList.add('text-danger');
        errorPassword.textContent = "La contraseña debe tener al menos 8 caracteres.";
        return false;
    } else {
        inputPassword.classList.remove('is-invalid');
        inputPassword.classList.add('is-valid');
        errorPassword.classList.remove('text-danger');
        errorPassword.textContent = "";
        return true;
    }
}

// Evento de validación cuando los inputs pierden el foco
inputEmail.addEventListener('focusout', validarEmail);
inputPassword.addEventListener('focusout', validarPassword);

// Función para verificar el login con AJAX
function verificarLogin() {
    const email = inputEmail.value.trim();
    const password = inputPassword.value.trim();

    fetch('../assets/php/login.php', {  // Cambia la URL a tu API real
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email, password: password })
    })
    .then(response => response.json())
    .then(data => {
        console.log('Datos cifrados:');
        if (data.success) {
            // Convertir el objeto 'data' a texto
            let textoData = JSON.stringify(data);
        
            const claveCesar = 3;
        
            // Cifrar el texto de 'data'
            const textoCifrado = cifrarCesar(textoData, claveCesar);
        
            // Almacenar los datos cifrados en localStorage
            localStorage.setItem('datosCifrados', textoCifrado);
        
            // Redirigir según el rol del usuario
            if (data.rol === "Professor") {
                window.location.href = "../pages/profesor/profesorInicio.html";
            } else if (data.rol === "Admin Escola") {
                window.location.href = "../pages/adminEscuela/adminEscuelaInicio.html";
            } else if (data.rol === "Admin App") {
                window.location.href = "../pages/adminAplicacion/adminAplicacionInicio.html";
            }
            } else {
                errorForm.textContent = "Correo o contraseña incorrectos.";
                errorForm.classList.add('text-danger');
            }
    })
    .catch(error => {
        console.error('Error en la petición:', error);
        errorForm.textContent = "Hubo un error en la autenticación.";
        errorForm.classList.add('text-danger');
    });
}

// Evento para validar el formulario y hacer login
submitButton.addEventListener('click', function (e) {
    e.preventDefault();

    errorForm.textContent = "";
    errorForm.classList.remove('text-danger');

    if (inputEmail.value.trim() === "" || inputPassword.value.trim() === "") {
        errorForm.textContent = "Por favor, introduce el correo y la contraseña.";
        errorForm.classList.add('text-danger');
        return false;
    }

    const isEmailValid = validarEmail();
    const isPasswordValid = validarPassword();

    if (isEmailValid && isPasswordValid) {
        verificarLogin();
    }
});
