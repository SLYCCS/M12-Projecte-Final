let escuela;
let incidenciasFiltradas = [];

// Función para cifrar un texto usando un desplazamiento (clave)
function cifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) { // Solo ciframos las letras
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65; // Para minúsculas (97) y mayúsculas (65)
            return String.fromCharCode(((code - base + clave) % 26) + base);
        }
        return char; // No ciframos otros caracteres
    }).join('');
}

// Función para descifrar un texto usando un desplazamiento (clave)
function descifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) {
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65;
            return String.fromCharCode(((code - base - clave + 26) % 26) + base); // Restamos la clave para descifrar
        }
        return char; // No desciframos otros caracteres
    }).join('');
}
// Llenar el select de clases en el modal de creación de incidencia
function llenarSelectModalClases(clases) {
    const selectClasesModal = document.getElementById('selectClase');
    selectClasesModal.innerHTML = '<option value="">Seleccione una clase</option>';
    console.log(clases);
    
    clases.forEach(clase => {
        const option = document.createElement('option');
        option.value = clase.id;
        option.textContent = clase.nom;
        selectClasesModal.appendChild(option);
    });
}
// Guardar los datos del formulario temporalmente
let datosIncidenciaPendiente = null;

// Mostrar el modal de confirmación antes de crear la incidencia
document.getElementById('btnGuardarIncidencia').addEventListener('click', function (e) {
    e.preventDefault();

    // Recoge los valores del formulario
    const titulo = document.getElementById('tituloIncidencia').value.trim();
    const idClase = document.getElementById('selectClase').value;
    const prioridad = document.getElementById('selectTipoIncidencia').value;
    const descripcion = document.getElementById('descripcionIncidencia').value.trim();

    // Validación básica
    if (!titulo || !idClase || !prioridad || !descripcion) {
        alert('Por favor, rellena todos los campos.');
        return;
    }

    // Guarda los datos temporalmente para usarlos tras la confirmación
    datosIncidenciaPendiente = {
        titol: titulo,
        id_aula: idClase,
        descripcio: descripcion,
        prioritat: prioridad,
        estat: 'Pendent',
        data_incidencia: new Date().toISOString().split('T')[0],
        id_professor: dataDescifrada.id
    };

    // Muestra el modal de confirmación
    const modalPregunta = new bootstrap.Modal(document.getElementById('modalPregunta'));
    modalPregunta.show();
});

// Acción al confirmar la creación de la incidencia
document.getElementById('btnConfirmarIncidencia').addEventListener('click', async function () {
    if (!datosIncidenciaPendiente) return;

    try {
        const response = await fetch('../../assets/php/crearIncidencia.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(datosIncidenciaPendiente)
        });

        const result = await response.json();

        if (result.success) {
            // Cierra el modal de confirmación y el de incidencia
            bootstrap.Modal.getInstance(document.getElementById('modalPregunta')).hide();
            const modalIncidencia = bootstrap.Modal.getInstance(document.getElementById('modalIncidencia'));
            if (modalIncidencia) modalIncidencia.hide();

            // Limpia el formulario
            document.getElementById('incidenciaForm').reset();

            // Recarga la lista de incidencias
            await cargarIncidenciasProfesor();
        } else {
            alert('Error al crear la incidencia: ' + (result.message || 'Inténtalo de nuevo.'));
        }
    } catch (error) {
        alert('Error al conectar con el servidor.');
        console.error(error);
    } finally {
        datosIncidenciaPendiente = null;
    }
});
// Modificar la función cargarIncidenciasProfesor para incluir el llenado del select del modal
async function cargarIncidenciasProfesor() {
    try {
        // Mostrar el nombre del profesor
        const nombreProfesorElement = document.getElementById('nombreUsuarioBienvenida');
        if (nombreProfesorElement) {
            nombreProfesorElement.textContent = dataDescifrada.nombre;
        }

        // Obtener datos de la escuela y sus incidencias
        const response = await fetch('../../assets/php/escuelaClases.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id_escola: dataDescifrada.id_escola })
        });

        const data = await response.json();
        escuela = data[0] || {};
        incidenciasFiltradas = escuela.incidencias || [];

        // Mostrar todas las incidencias inicialmente
        mostrarIncidencias(incidenciasFiltradas);
        console.log(escuela.aulas);
        
        // Llenar select de clases para filtrado
        llenarSelectFiltroClases(escuela.aulas || []);
        
        // Llenar select de clases en el modal de creación de incidencia
        llenarSelectModalClases(escuela.aulas || []);
        
    } catch (error) {
        console.error('Error al cargar las incidencias:', error);
    }
}

// Verificar si el usuario está logueado al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    const textoCifradoRecuperado = localStorage.getItem('datosCifrados');
    
    if (textoCifradoRecuperado) {
        const claveCesar = 3; // Usar la misma clave para el descifrado
        const textoDescifrado = descifrarCesar(textoCifradoRecuperado, claveCesar);
        dataDescifrada = JSON.parse(textoDescifrado);
        
        if (dataDescifrada.rol === "Professor") {
            console.log('Rol correcto');
            cargarIncidenciasProfesor();
            configurarFiltros();
        } else {
            // Redirigir si no es profesor
            window.location.href = dataDescifrada.rol === "Admin App" 
                ? "../adminAplicacion/adminAplicacionInicio.html" 
                : "../adminEscuela/adminEscuelaInicio.html";
        }
    } else {
        window.location.href = "../login.html";
    }
});

// Evento para cerrar sesión
document.getElementById('btnCerrarSesion').addEventListener('click', function() {
    localStorage.removeItem('datosCifrados');
    window.location.href = "../login.html";
});


// Función para mostrar las incidencias en la página
function mostrarIncidencias(incidencias) {
    const listaIncidencias = document.getElementById('listaIncidencias');
    listaIncidencias.innerHTML = ""; // Limpiar contenido previo

    if (incidencias.length === 0) {
        listaIncidencias.innerHTML = '<div class="col-12"><p class="text-center">No se encontraron incidencias</p></div>';
        return;
    }

    incidencias.forEach(incidencia => {
        const claseIncidencia = escuela.aulas.find(aula => aula.id === incidencia.id_aula);
        const nombreClaseIncidencia = claseIncidencia ? claseIncidencia.nom : 'Clase desconocida';
        
        const divIncidencia = document.createElement('div');
        divIncidencia.classList.add('col-md-4', 'mb-3');
        
        // Determinar clase CSS según prioridad
        let prioridadClass = '';
        switch(incidencia.prioritat) {
            case 'Alta': prioridadClass = 'border-danger'; break;
            case 'Mitja': prioridadClass = 'border-warning'; break;
            case 'Baixa': prioridadClass = 'border-success'; break;
        }
        
        divIncidencia.innerHTML = `
            <div class="card ${prioridadClass}">
                <div class="card-body">
                    <h5 class="card-title">${incidencia.titol}</h5>
                    <p class="card-text">Clase: ${nombreClaseIncidencia}</p>
                    <p class="card-text">Fecha: ${incidencia.data_incidencia}</p>
                    <p class="card-text">Prioridad: 
                        <span class="badge ${getBadgeClass(incidencia.prioritat)}">
                            ${incidencia.prioritat}
                        </span>
                    </p>
                    <p class="card-text">Estado: 
                        <span class="badge ${getEstadoBadgeClass(incidencia.estat)}">
                            ${incidencia.estat}
                        </span>
                    </p>
                    <p class="card-text">Descripción: ${incidencia.descripcio}</p>
                </div>
            </div>
        `;
        listaIncidencias.appendChild(divIncidencia);
    });
}

// Función auxiliar para obtener clase CSS del badge según prioridad
function getBadgeClass(prioridad) {
    switch(prioridad) {
        case 'Alta': return 'bg-danger';
        case 'Mitja': return 'bg-warning text-dark';
        case 'Baixa': return 'bg-success';
        default: return 'bg-secondary';
    }
}

// Función auxiliar para obtener clase CSS del badge según estado
function getEstadoBadgeClass(estado) {
    switch(estado) {
        case 'Pendent': return 'bg-secondary';
        case 'En progres': return 'bg-primary';
        case 'Resolta': return 'bg-success';
        default: return 'bg-dark';
    }
}

// Configurar los filtros
function configurarFiltros() {
    // Filtro por clase
    document.getElementById('filtroClase').addEventListener('change', function() {
        aplicarFiltros();
    });
    
    // Filtro por prioridad
    document.getElementById('filtroPrioridad').addEventListener('change', function() {
        aplicarFiltros();
    });
    
    // Filtro por estado
    document.getElementById('filtroEstado').addEventListener('change', function() {
        aplicarFiltros();
    });
    
    // Botón para limpiar filtros
    document.getElementById('limpiarFiltros').addEventListener('click', function() {
        document.getElementById('filtroClase').value = 'todas';
        document.getElementById('filtroPrioridad').value = 'todas';
        document.getElementById('filtroEstado').value = 'todas';
        aplicarFiltros();
    });
}

// Aplicar todos los filtros seleccionados
function aplicarFiltros() {
    const filtroClase = document.getElementById('filtroClase').value;
    const filtroPrioridad = document.getElementById('filtroPrioridad').value;
    const filtroEstado = document.getElementById('filtroEstado').value;
    
    incidenciasFiltradas = escuela.incidencias.filter(incidencia => {
        // Filtro por clase
        if (filtroClase !== 'todas' && incidencia.id_aula !== parseInt(filtroClase)) {
            return false;
        }
        
        // Filtro por prioridad
        if (filtroPrioridad !== 'todas' && incidencia.prioritat !== filtroPrioridad) {
            return false;
        }
        
        // Filtro por estado
        if (filtroEstado !== 'todas' && incidencia.estat !== filtroEstado) {
            return false;
        }
        
        return true;
    });
    
    mostrarIncidencias(incidenciasFiltradas);
}

// Llenar el select de clases para el filtrado
function llenarSelectFiltroClases(clases) {
    const selectClases = document.getElementById('filtroClase');
    selectClases.innerHTML = '<option value="todas">Todas las clases</option>';

    clases.forEach(clase => {
        const option = document.createElement('option');
        option.value = clase.id;
        option.textContent = clase.nom;
        selectClases.appendChild(option);
    });
}