<?php
header("Content-Type: application/json");
require_once 'db.php'; // Database connection


    try {
        $stmt = $pdo->prepare("SELECT * FROM incidencia");
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        // Returns the array directly
        echo json_encode($result);
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
$pdo = null;
?>