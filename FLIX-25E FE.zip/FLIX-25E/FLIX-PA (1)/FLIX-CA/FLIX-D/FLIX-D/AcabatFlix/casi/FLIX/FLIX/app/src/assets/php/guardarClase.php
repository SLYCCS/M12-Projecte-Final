<?php
header("Content-Type: application/json");
require_once 'db.php'; // Conexión a la base de datos
// Obtener los datos enviados en el cuerpo de la solicitud
$data = json_decode(file_get_contents('php://input'), true);

// Verificar si los datos están presentes
if (isset($data['id']) && isset($data['nom']) && isset($data['num_mesas']) && isset($data['num_sillas']) && isset($data['num_teclados']) && isset($data['num_monitores']) && isset($data['num_ordenadores']) && isset($data['num_ratones'])) {
    
    // Asignar los datos a variables
    $id = $data['id'];
    $nom = $data['nom'];
    $num_mesas = $data['num_mesas'];
    $num_sillas = $data['num_sillas'];
    $num_teclados = $data['num_teclados'];
    $num_monitores = $data['num_monitores'];
    $num_ordenadores = $data['num_ordenadores'];
    $num_ratones = $data['num_ratones'];


    // actualizar la clase en la base de datos
    $sql = "UPDATE aula SET nom = ?, num_mesas = ?, num_sillas = ?, num_teclados = ?, num_monitores = ?, num_ordenadores = ?, num_ratones = ? WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$nom, $num_mesas, $num_sillas, $num_teclados, $num_monitores, $num_ordenadores, $num_ratones, $id]);

    // Verificar si la clase se ha actualizado correctamente
    if ($stmt->rowCount() === 1) {
        echo json_encode(["success" => "Clase actualizada correctamente"]);
    } else {
        echo json_encode(["error" => "Error al actualizar la clase"]);
    }
} else {
    echo json_encode(["error" => "Datos incompletos"]);
}
?>