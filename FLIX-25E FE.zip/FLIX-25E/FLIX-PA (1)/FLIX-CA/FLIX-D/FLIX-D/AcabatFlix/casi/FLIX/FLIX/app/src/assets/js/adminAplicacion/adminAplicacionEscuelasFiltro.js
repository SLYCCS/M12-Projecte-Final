// Función para cifrar un texto usando un desplazamiento (clave)
function cifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) { // Solo ciframos las letras
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65; // Para minúsculas (97) y mayúsculas (65)
            return String.fromCharCode(((code - base + clave) % 26) + base);
        }
        return char; // No ciframos otros caracteres
    }).join('');
}

// Función para descifrar un texto usando un desplazamiento (clave)
function descifrarCesar(texto, clave) {
    return texto.split('').map(char => {
        if (char.match(/[a-z]/i)) {
            const code = char.charCodeAt(0);
            const base = (char.toLowerCase() === char) ? 97 : 65;
            return String.fromCharCode(((code - base - clave + 26) % 26) + base); // Restamos la clave para descifrar
        }
        return char; // No desciframos otros caracteres
    }).join('');
}

// Evento para cerrar sesión
document.getElementById('btnCerrarSesion').addEventListener('click', function() {
    // Eliminar usuario y escuela del localStorage
    localStorage.removeItem('datosCifrados');
    
    // Redirigir a la página de login
    window.location.href = "../login.html";
});

// Recuperar los datos cifrados desde localStorage
const textoCifradoRecuperado = localStorage.getItem('datosCifrados');
if (textoCifradoRecuperado) {
    const claveCesar = 3; // Usar la misma clave para el descifrado

    // Descifrar los datos
    const textoDescifrado = descifrarCesar(textoCifradoRecuperado, claveCesar);

    // Convertir el texto descifrado de vuelta al objeto
    const dataDescifrada = JSON.parse(textoDescifrado);

    console.log('Datos descifrados:', dataDescifrada);
    if (dataDescifrada.rol === "Admin App") {
        console.log('Rol correcto');
    } else if (dataDescifrada.rol === "Professor") {
        window.location.href = "../profesor/profesorInicio.html";
    } else if (dataDescifrada.rol === "Admin Escola") {
        window.location.href = "../adminEscuela/adminEscuelaInicio.html";
    }
    document.getElementById('nombreUsuarioBienvenida').innerText = dataDescifrada.nombre;
} else {
    window.location.href = "../login.html"; // Redirigir al login si no hay datos cifrados
}


// Función para formatear la fecha
function formatFecha(fechaString) {
    if (!fechaString) return 'No disponible';
    
    const fecha = new Date(fechaString);
    if (isNaN(fecha.getTime())) return 'Fecha inválida';
    
    return fecha.toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Función para mostrar el modal de crear escuela
function mostrarModalCrearEscuela() {
    document.getElementById('nombreNuevaEscuela').value = '';
    document.getElementById('modoEdicionEscuela').value = 'crear';
    document.getElementById('direccionNuevaEscuela').value = '';
    document.getElementById('idEscuela').value = '';
    
    document.getElementById('modalCrearEscuelaLabel').textContent = 'Crear Nueva Escuela';
    
    const modalEscuela = new bootstrap.Modal(document.getElementById('modalCrearEscuela'));
    modalEscuela.show();
    
    const btnGuardar = document.getElementById('btnGuardarEscuela');
    btnGuardar.onclick = () => guardarEscuela(null);
}

// Función para editar una escuela
async function editarEscuela(id) {
    const escuelas = await cargarDatosEscuelas();
    const escuela = escuelas.find(esc => esc.id === id);
    
    if (escuela) {
        document.getElementById('nombreNuevaEscuela').value = escuela.nom;
        document.getElementById('direccionNuevaEscuela').value = escuela.direccio;
        document.getElementById('modoEdicionEscuela').value = 'editar';
        document.getElementById('idEscuela').value = escuela.id;
        
        document.getElementById('modalCrearEscuelaLabel').textContent = 'Editar Escuela';
        
        const btnGuardar = document.getElementById('btnGuardarEscuela');
        btnGuardar.onclick = function() {
            if (!document.getElementById('nombreNuevaEscuela').value.trim()) {
                alert("El nombre de la escuela no puede estar vacío.");
                return;
            }
            if (!document.getElementById('direccionNuevaEscuela').value.trim()) {
                alert("La dirección de la escuela no puede estar vacía.");
                return;
            }
            guardarEscuela(escuela.id);
        };

        const modalEscuela = new bootstrap.Modal(document.getElementById('modalCrearEscuela'));
        modalEscuela.show();
    }
}

// Función para guardar una escuela
async function guardarEscuela(id) {
    const nombre = document.getElementById('nombreNuevaEscuela').value.trim();
    const direccion = document.getElementById('direccionNuevaEscuela').value.trim();
    const modoEdicion = document.getElementById('modoEdicionEscuela').value;
    
    if (!nombre) {
        alert("El nombre de la escuela no puede estar vacío.");
        return;
    }

    if (!direccion) {
        alert("La dirección de la escuela no puede estar vacía.");
        return;
    }

    const data = {
        id: id,
        nom: nombre,
        direccio: direccion
    };

    try {
        let url, method;
        
        if (modoEdicion === 'editar' && id !== null) {
            url = '../../assets/php/actualizarescuelas.php';
            method = 'PUT';
        } else {
            url = '../../assets/php/crearescuelas.php';
            method = 'POST';
        }

        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();
        
        if (result.success) {
            console.log(modoEdicion === 'editar' ? 'Escuela actualizada con éxito' : 'Escuela creada con éxito');
            mostrarEscuelas();
            
            const modalEscuela = bootstrap.Modal.getInstance(document.getElementById('modalCrearEscuela'));
            modalEscuela.hide();
        } else {
            console.error('Error al guardar la escuela:', result.message);
            alert('Error al guardar la escuela: ' + (result.message || 'Error desconocido'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al conectar con el servidor');
    }
}

// Función para eliminar una escuela
async function eliminarEscuela(id) {
    const escuelas = await cargarDatosEscuelas();
    const escuela = escuelas.find(esc => esc.id === id);

    if (escuela) {
        // Mostrar modal de confirmación
        const modalPregunta = new bootstrap.Modal(document.getElementById('modalPregunta'));
        document.getElementById('modalPreguntaLabel').textContent = `¿Estás seguro de que deseas eliminar la escuela ${escuela.nom}?`;

        document.getElementById('btnConfirmarIncidencia').onclick = async function() {
            try {
                const response = await fetch('../../assets/php/eliminarescuelas.php', {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ id: escuela.id })
                });

                const result = await response.json();
                
                if (result.success) {
                    console.log('Escuela eliminada con éxito');
                    mostrarEscuelas();
                } else {
                    console.error('Error al eliminar la escuela:', result.message);
                    alert('Error al eliminar la escuela: ' + (result.message || 'Error desconocido'));
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Error al conectar con el servidor');
            }

            modalPregunta.hide();
        };

        modalPregunta.show();
    }
}

// Función para aplicar el filtro de escuelas - Versión corregida
async function aplicarFiltroEscuelas() {
    const nombre = document.getElementById('filtroNombre').value.trim().toLowerCase();
    const direccion = document.getElementById('filtroDireccion').value.trim().toLowerCase();
    const anio = document.getElementById('filtroAnio').value;
    const mes = document.getElementById('filtroMes').value;
    const dia = document.getElementById('filtroDia').value;

    // Obtener todas las escuelas
    const escuelas = await cargarDatosEscuelas();
    
    // Filtrar escuelas según los criterios
    const escuelasFiltradas = escuelas.filter(escuela => {
        // Filtrar por nombre
        if (nombre && !escuela.nom.toLowerCase().includes(nombre)) {
            return false;
        }
        
        // Filtrar por dirección
        if (direccion && !escuela.direccio.toLowerCase().includes(direccion)) {
            return false;
        }
        
        // Filtrar por fecha solo si la escuela tiene fecha de creación
        if (anio || mes || dia) {
            // Verificar si la escuela tiene fecha de creación
            if (!escuela.data_creacio || escuela.data_creacio === 'No disponible') {
                return false;
            }
            
            // Convertir la fecha de creación a objeto Date
            const fechaCreacion = new Date(escuela.data_creacio);
            
            // Verificar si la fecha es válida
            if (isNaN(fechaCreacion.getTime())) {
                return false;
            }
            
            // Aplicar filtros de fecha
            if (anio && fechaCreacion.getFullYear() !== parseInt(anio)) {
                return false;
            }
            
            if (mes && (fechaCreacion.getMonth() + 1) !== parseInt(mes)) {
                return false;
            }
            
            if (dia && fechaCreacion.getDate() !== parseInt(dia)) {
                return false;
            }
        }
        
        return true;
    });

    // Mostrar las escuelas filtradas
    mostrarEscuelas(escuelasFiltradas);
}

// Función para cargar las escuelas desde la base de datos - Versión corregida
async function cargarDatosEscuelas() {
    try {
        const response = await fetch('../../assets/php/escuelasAdmin.php');
        if (!response.ok) {
            throw new Error('Error al cargar las escuelas');
        }
        const data = await response.json();
        
        // Formatear la fecha y asegurarse de que sea válida
        return data.map(escuela => {
            let fechaFormateada = 'No disponible';
            
            if (escuela.data_creacio) {
                const fecha = new Date(escuela.data_creacio);
                if (!isNaN(fecha.getTime())) {
                    fechaFormateada = fecha.toISOString().split('T')[0]; // Formato YYYY-MM-DD
                }
            }
            
            return {
                ...escuela,
                data_creacio: fechaFormateada,
                fechaOriginal: escuela.data_creacio // Mantenemos la fecha original para filtrado
            };
        });
    } catch (error) {
        console.error(error);
        return [];
    }
}


// Función para mostrar las escuelas
function mostrarEscuelas(escuelas = null) {
    const listaEscuelas = document.getElementById('listaEscuelas');
    const contadorEscuelas = document.getElementById('contadorEscuelas');
    
    // Si no se proporciona el parámetro, cargamos todas las escuelas
    if (escuelas === null) {
        cargarDatosEscuelas().then(escuelas => {
            renderizarEscuelas(escuelas);
            contadorEscuelas.textContent = `${escuelas.length} escuelas`;
        });
        return;
    }
    
    renderizarEscuelas(escuelas);
    contadorEscuelas.textContent = `${escuelas.length} escuelas`;
}

// Función auxiliar para renderizar las escuelas
function renderizarEscuelas(escuelas) {
    const listaEscuelas = document.getElementById('listaEscuelas');
    listaEscuelas.innerHTML = ''; // Limpiar el contenido previo

    if (!escuelas || escuelas.length === 0) {
        listaEscuelas.innerHTML = `
            <div class="col-12 text-center py-4">
                <p class="text-muted">No se encontraron escuelas con los criterios de búsqueda.</p>
                <button class="btn btn-primary" onclick="limpiarFiltro()">Mostrar todas</button>
            </div>
        `;
        return;
    }

    escuelas.forEach((escuela) => {
        const divEscuela = document.createElement('div');
        divEscuela.classList.add('col-md-4', 'mb-4');
        divEscuela.innerHTML = `
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">${escuela.nom}</h5>
                    <p class="card-text"><i class="bi bi-geo-alt"></i> ${escuela.direccio}</p>
                    <p class="card-text"><small class="text-muted">Creada: ${escuela.data_creacio}</small></p>
                </div>
                <div class="card-footer bg-transparent">
                    <button class="btn btn-sm btn-outline-secondary" onclick="editarEscuela(${escuela.id})">
                        <i class="bi bi-pencil"></i> Editar
                    </button>
                    <button class="btn btn-sm btn-outline-danger float-end" onclick="eliminarEscuela(${escuela.id})">
                        <i class="bi bi-trash"></i> Eliminar
                    </button>
                </div>
            </div>
        `;
        listaEscuelas.appendChild(divEscuela);
    });
}

// Función para limpiar el filtro
function limpiarFiltro() {
    document.getElementById('filtroNombre').value = '';
    document.getElementById('filtroDireccion').value = '';
    document.getElementById('filtroAnio').value = '';
    document.getElementById('filtroMes').value = '';
    document.getElementById('filtroDia').value = '';
    
    // Mostrar todas las escuelas
    mostrarEscuelas();
}

// Event listeners para los botones de filtro
document.addEventListener('DOMContentLoaded', function() {
    // Verificar autenticación y rol
    const textoCifradoRecuperado = localStorage.getItem('datosCifrados');
    if (textoCifradoRecuperado) {
        const claveCesar = 3;
        const textoDescifrado = descifrarCesar(textoCifradoRecuperado, claveCesar);
        const dataDescifrada = JSON.parse(textoDescifrado);

        if (dataDescifrada.rol !== "Admin App") {
            // Redirigir según el rol
            if (dataDescifrada.rol === "Professor") {
                window.location.href = "../profesor/profesorInicio.html";
            } else if (dataDescifrada.rol === "Admin Escola") {
                window.location.href = "../adminEscuela/adminEscuelaInicio.html";
            }
        }
    } else {
        window.location.href = "../login.html";
    }

    // Cargar escuelas al iniciar
    mostrarEscuelas();

    // Eventos para los botones de filtro
    document.getElementById('btnAplicarFiltro').addEventListener('click', aplicarFiltroEscuelas);
    document.getElementById('btnLimpiarFiltro').addEventListener('click', limpiarFiltro);
});