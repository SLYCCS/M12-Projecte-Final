<?php
require_once 'db.php';
header('Content-Type: application/json');
try {
    $stmt = $pdo->query('
        SELECT u.*
        FROM usuari u
    ');
    $usuaris = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($usuaris);
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
}
?>