<?php
require_once 'db.php';
header('Content-Type: application/json');
try {
    $stmt = $pdo->query('SELECT * FROM escola');
    $escuelas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($escuelas);
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
}
?>